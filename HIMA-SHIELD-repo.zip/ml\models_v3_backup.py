"""
HIMA-SHIELD ML Models.

Implements:
1. StatisticalBaseline — Z-score anomaly detection with rolling windows
2. IsolationForestDetector — Unsupervised anomaly detection
3. ReliabilityAwareDetector — Proposed research contribution:
   sensor-reliability-weighted anomaly detection with uncertainty estimation

All models are designed for physiological time-series under simulated
high-altitude conditions. This is a research prototype.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import joblib


FEATURE_COLS = ["heart_rate", "spo2", "respiratory_rate", "temperature"]


@dataclass
class AnomalyOutput:
    """Standardized anomaly detection output."""
    scores: np.ndarray           # anomaly scores (higher = more anomalous)
    predictions: np.ndarray      # binary anomaly labels
    uncertainties: np.ndarray    # model uncertainty estimates
    reliability_scores: np.ndarray  # per-sample sensor reliability
    feature_contributions: list[dict]  # per-sample feature attribution
    model_name: str = ""
    threshold: float = 0.0


class StatisticalBaseline:
    """Z-score anomaly detection against a rolling, personalized baseline.

    For each subject, every sample is compared with the rolling median of that
    subject's own preceding ``window_size`` samples. Deviations are scaled by a
    per-feature noise scale learned from training subjects. Because the baseline
    is built from each subject's own history, the model works for subjects not
    seen during training (required for subject-level train/test splits).

    The decision threshold is calibrated on training data to the expected
    contamination rate, so it is comparable to the Isolation Forest models.
    """

    def __init__(
        self,
        window_size: int = 30,
        z_threshold: Optional[float] = None,
        contamination: float = 0.05,
    ):
        self.window_size = window_size
        self.z_threshold = z_threshold  # None -> calibrated during fit
        self.contamination = contamination
        self.noise_scale: dict[str, float] = {}
        self.baselines: dict[str, dict] = {}
        self.name = "StatisticalBaseline"

    def _rolling_z(self, df: pd.DataFrame, subject_col: str) -> pd.DataFrame:
        """Absolute z-scores of each feature vs. the subject's rolling median."""
        z = pd.DataFrame(index=df.index, columns=FEATURE_COLS, dtype=float)
        groups = df.groupby(subject_col, sort=False) if subject_col in df.columns else [(None, df)]
        for _, group in groups:
            for col in FEATURE_COLS:
                if col not in group.columns:
                    continue
                s = group[col].astype(float)
                med = s.rolling(self.window_size, min_periods=5).median().shift(1)
                med = med.fillna(s.median())  # warm-up period
                z.loc[group.index, col] = (s - med).abs() / self.noise_scale.get(col, 1.0)
        return z

    def fit(self, df: pd.DataFrame, subject_col: str = "subject_id") -> None:
        """Learn per-feature noise scales and calibrate the threshold."""
        self.baselines = {}
        residuals: dict[str, list] = {c: [] for c in FEATURE_COLS}
        for subj, group in df.groupby(subject_col):
            baseline = {}
            for col in FEATURE_COLS:
                if col not in group.columns:
                    continue
                s = group[col].astype(float)
                vals = s.dropna()
                if len(vals) == 0:
                    continue
                baseline[col] = {
                    "mean": float(vals.mean()),
                    "std": float(max(vals.std(), 1e-6)),
                    "median": float(vals.median()),
                }
                med = s.rolling(self.window_size, min_periods=5).median().shift(1)
                residuals[col].append((s - med).dropna().values)
            self.baselines[str(subj)] = baseline

        for col in FEATURE_COLS:
            r = np.concatenate(residuals[col]) if residuals[col] else np.array([1.0])
            mad = np.median(np.abs(r - np.median(r)))
            self.noise_scale[col] = float(max(1.4826 * mad, 1e-6))

        if self.z_threshold is None:
            train_scores = self._rolling_z(df, subject_col).max(axis=1, skipna=True).fillna(0).values
            self.z_threshold = float(np.quantile(train_scores, 1 - self.contamination))

    def predict(self, df: pd.DataFrame, subject_col: str = "subject_id") -> AnomalyOutput:
        """Score each row against its subject's rolling baseline."""
        n = len(df)
        z = self._rolling_z(df, subject_col)
        scores = z.max(axis=1, skipna=True).fillna(0).values.astype(float)
        threshold = self.z_threshold if self.z_threshold is not None else 2.5

        z_arr = z.values
        feature_contribs = []
        for i in range(n):
            feature_contribs.append({
                col: (None if np.isnan(z_arr[i, j]) else round(float(z_arr[i, j]), 3))
                for j, col in enumerate(FEATURE_COLS)
            })

        predictions = (scores > threshold).astype(int)
        # Uncertainty: lower for very clear anomalies, higher near threshold
        dist_from_threshold = np.abs(scores - threshold) / max(threshold, 1e-6)
        uncertainties = 1.0 / (1.0 + 3.0 * dist_from_threshold)

        return AnomalyOutput(
            scores=scores,
            predictions=predictions,
            uncertainties=uncertainties,
            reliability_scores=np.ones(n),
            feature_contributions=feature_contribs,
            model_name=self.name,
            threshold=threshold,
        )

    def get_params(self) -> dict:
        return {
            "window_size": self.window_size,
            "z_threshold": self.z_threshold,
            "contamination": self.contamination,
        }


class IsolationForestDetector:
    """Isolation Forest anomaly detector with feature contribution estimation."""

    def __init__(
        self,
        contamination: float = 0.05,
        n_estimators: int = 200,
        random_state: int = 42,
    ):
        self.contamination = contamination
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.model = IsolationForest(
            contamination=contamination,
            n_estimators=n_estimators,
            random_state=random_state,
        )
        self.scaler = StandardScaler()
        self.name = "IsolationForest"
        self._fitted = False

    def fit(self, df: pd.DataFrame) -> None:
        """Fit on the feature columns."""
        features = df[FEATURE_COLS].dropna()
        if len(features) < 10:
            raise ValueError("Need at least 10 complete rows to fit IsolationForest.")
        X = self.scaler.fit_transform(features)
        self.model.fit(X)
        self._fitted = True

    def predict(self, df: pd.DataFrame) -> AnomalyOutput:
        """Score and predict anomalies."""
        if not self._fitted:
            raise RuntimeError("Model not fitted. Call fit() first.")

        n = len(df)
        features = df[FEATURE_COLS].copy()

        # Handle missing values with median imputation (tracked)
        missing_mask = features.isna()
        features_filled = features.fillna(features.median())

        X = self.scaler.transform(features_filled)

        # Anomaly scores (sklearn convention: lower = more anomalous)
        raw_scores = self.model.decision_function(X)
        # Invert so higher = more anomalous
        scores = -raw_scores
        predictions = self.model.predict(X)
        predictions = (predictions == -1).astype(int)

        # Feature contributions via marginal scoring (batched):
        # score with vs. without each feature (feature set to its scaled mean = 0)
        delta = np.zeros((n, len(FEATURE_COLS)))
        for j in range(len(FEATURE_COLS)):
            X_mod = X.copy()
            X_mod[:, j] = 0
            delta[:, j] = scores - (-self.model.decision_function(X_mod))
        missing_arr = missing_mask.values
        feature_contribs = []
        for i in range(n):
            contribs = {}
            for j, col in enumerate(FEATURE_COLS):
                contribs[col] = None if missing_arr[i, j] else round(float(delta[i, j]), 4)
            feature_contribs.append(contribs)

        # Reliability: penalize rows with missing values
        reliability = 1.0 - missing_mask.mean(axis=1).values

        # Uncertainty from score distribution
        score_std = np.std(scores) if np.std(scores) > 0 else 1.0
        uncertainties = np.exp(-np.abs(scores - np.mean(scores)) / score_std)

        return AnomalyOutput(
            scores=scores,
            predictions=predictions,
            uncertainties=uncertainties,
            reliability_scores=reliability,
            feature_contributions=feature_contribs,
            model_name=self.name,
            threshold=0.0,
        )

    def save(self, path: str) -> None:
        joblib.dump({"model": self.model, "scaler": self.scaler}, path)

    def load(self, path: str) -> None:
        data = joblib.load(path)
        self.model = data["model"]
        self.scaler = data["scaler"]
        self._fitted = True

    def get_params(self) -> dict:
        return {
            "contamination": self.contamination,
            "n_estimators": self.n_estimators,
            "random_state": self.random_state,
        }


class ReliabilityAwareDetector:
    """
    Proposed research contribution: Reliability-Aware Anomaly Detection.

    Hypothesis: Incorporating sensor reliability estimation into anomaly
    scoring improves interpretation when inputs are missing, noisy, or
    affected by distribution shifts.

    Approach:
    1. Estimate per-feature reliability from data quality signals
       (missingness patterns, value range violations, temporal consistency).
    2. Weight anomaly scores by reliability — unreliable features have
       reduced influence on the final score.
    3. Estimate uncertainty that accounts for both model and data uncertainty.
    4. Provide abstention when reliability is too low.

    This is a research hypothesis, not a validated method.
    """

    def __init__(
        self,
        contamination: float = 0.05,
        reliability_threshold: float = 0.3,
        abstention_threshold: float = 0.5,
        n_estimators: int = 200,
        random_state: int = 42,
    ):
        self.contamination = contamination
        self.reliability_threshold = reliability_threshold
        self.abstention_threshold = abstention_threshold
        self.n_estimators = n_estimators
        self.random_state = random_state

        self.base_model = IsolationForest(
            contamination=contamination,
            n_estimators=n_estimators,
            random_state=random_state,
        )
        self.scaler = StandardScaler()
        self.name = "ReliabilityAwareDetector"
        self._fitted = False
        self._training_stats: dict = {}

    def _compute_reliability(
        self, df: pd.DataFrame, features: pd.DataFrame
    ) -> pd.DataFrame:
        """Estimate per-feature reliability for each sample.

        Reliability factors:
        - Completeness: is the value present?
        - Range validity: is the value within physiological bounds?
        - Temporal consistency: how much does it deviate from neighbors?
        """
        RANGES = {
            "heart_rate": (30, 220),
            "spo2": (50, 100),
            "respiratory_rate": (4, 60),
            "temperature": (33, 43),
        }

        reliability = pd.DataFrame(index=features.index)

        for col in FEATURE_COLS:
            if col not in features.columns:
                reliability[col] = 0.0
                continue

            # Completeness
            completeness = (~features[col].isna()).astype(float)

            # Range validity
            vals = features[col].fillna(0)
            low, high = RANGES.get(col, (0, 1e6))
            in_range = ((vals >= low) & (vals <= high)).astype(float)
            in_range[features[col].isna()] = 0

            # Temporal consistency (deviation from local median)
            rolling_med = features[col].rolling(5, min_periods=1, center=False).median()
            deviation = (features[col] - rolling_med).abs()
            if col in self._training_stats and self._training_stats[col]["std"] > 0:
                consistency = 1.0 / (1.0 + deviation / self._training_stats[col]["std"])
            else:
                consistency = pd.Series(0.5, index=features.index)
            consistency = consistency.fillna(0.5)

            # Combined reliability
            reliability[col] = (0.4 * completeness + 0.3 * in_range + 0.3 * consistency)

        return reliability

    def fit(self, df: pd.DataFrame) -> None:
        """Fit the base model and compute training statistics."""
        features = df[FEATURE_COLS].copy()

        # Store training statistics
        for col in FEATURE_COLS:
            if col in features.columns:
                vals = features[col].dropna()
                self._training_stats[col] = {
                    "mean": float(vals.mean()),
                    "std": float(max(vals.std(), 1e-6)),
                    "median": float(vals.median()),
                }

        features_clean = features.dropna()
        if len(features_clean) < 10:
            raise ValueError("Need at least 10 complete rows.")

        X = self.scaler.fit_transform(features_clean)
        self.base_model.fit(X)

        # Calibrate threshold on clean training data
        raw_train_scores = -self.base_model.decision_function(X)
        # On clean training data, reliability is ~1.0, so weighted ≈ raw
        train_reliability = self._compute_reliability(df.loc[features_clean.index], features_clean)
        train_sample_rel = train_reliability.mean(axis=1).values
        weighted_train = raw_train_scores * train_sample_rel
        self._calibrated_threshold = float(np.percentile(weighted_train, 100 * (1 - self.contamination)))

        self._fitted = True

    def predict(self, df: pd.DataFrame) -> AnomalyOutput:
        """Reliability-weighted anomaly scoring with uncertainty."""
        if not self._fitted:
            raise RuntimeError("Model not fitted.")

        n = len(df)
        features = df[FEATURE_COLS].copy()

        # Compute reliability
        reliability = self._compute_reliability(df, features)
        sample_reliability = reliability.mean(axis=1).values

        # Impute missing with training medians
        for col in FEATURE_COLS:
            if col in features.columns and col in self._training_stats:
                features[col] = features[col].fillna(self._training_stats[col]["median"])

        X = self.scaler.transform(features)

        # Base anomaly scores
        raw_scores = -self.base_model.decision_function(X)

        # Reliability-weighted scores
        # When reliability is low, attenuate the anomaly score toward ambiguous
        weighted_scores = raw_scores * sample_reliability

        # Data uncertainty: higher when reliability is low
        data_uncertainty = 1.0 - sample_reliability

        # Model uncertainty: from score distribution
        score_spread = np.std(raw_scores) if np.std(raw_scores) > 0 else 1.0
        model_uncertainty = np.exp(-np.abs(raw_scores - np.mean(raw_scores)) / score_spread)

        # Combined uncertainty
        total_uncertainty = 0.5 * data_uncertainty + 0.5 * model_uncertainty

        # Predictions with abstention — use threshold calibrated during fit()
        threshold = self._calibrated_threshold
        predictions = np.zeros(n, dtype=int)
        for i in range(n):
            if sample_reliability[i] < self.abstention_threshold:
                predictions[i] = -1  # abstain
            elif weighted_scores[i] > threshold:
                predictions[i] = 1  # anomaly
            else:
                predictions[i] = 0  # normal

        # Feature contributions weighted by reliability
        delta = np.zeros((n, len(FEATURE_COLS)))
        for j in range(len(FEATURE_COLS)):
            X_mod = X.copy()
            X_mod[:, j] = 0
            delta[:, j] = raw_scores - (-self.base_model.decision_function(X_mod))
        rel_arr = reliability[FEATURE_COLS].values
        feature_contribs = []
        for i in range(n):
            contribs = {}
            for j, col in enumerate(FEATURE_COLS):
                rel = rel_arr[i, j]
                # unreliable features get no attribution
                contribs[col] = None if rel < 0.1 else round(float(delta[i, j] * rel), 4)
            feature_contribs.append(contribs)

        return AnomalyOutput(
            scores=weighted_scores,
            predictions=predictions,
            uncertainties=total_uncertainty,
            reliability_scores=sample_reliability,
            feature_contributions=feature_contribs,
            model_name=self.name,
            threshold=float(threshold),
        )

    def save(self, path: str) -> None:
        joblib.dump({
            "model": self.base_model,
            "scaler": self.scaler,
            "training_stats": self._training_stats,
            "params": self.get_params(),
        }, path)

    def load(self, path: str) -> None:
        data = joblib.load(path)
        self.base_model = data["model"]
        self.scaler = data["scaler"]
        self._training_stats = data["training_stats"]
        self._fitted = True

    def get_params(self) -> dict:
        return {
            "contamination": self.contamination,
            "reliability_threshold": self.reliability_threshold,
            "abstention_threshold": self.abstention_threshold,
            "n_estimators": self.n_estimators,
            "random_state": self.random_state,
        }
