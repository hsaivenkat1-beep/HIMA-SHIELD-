"""
HIMA-SHIELD ML Models (v4 audited release).

Implements:
1. StatisticalBaseline — Z-score anomaly detection with rolling windows
2. IsolationForestDetector — Unsupervised anomaly detection
3. ReliabilityAwareDetector — Proposed research contribution:
   sensor-reliability-weighted anomaly detection with selective abstention

All models are designed for physiological time-series under simulated
high-altitude conditions. This is a research prototype.

v4 audit changes (see v4_audit_report.md):
- RA uses the bounded Isolation Forest score s = -score_samples(X) in (0, 1]
  (Liu et al. 2008), so multiplying by reliability R in [0, 1] always
  attenuates the score. v3 multiplied the unbounded decision_function, which
  is negative for normal samples, so low reliability *raised* their scores.
- Temporal consistency is computed per subject against the previous
  `temporal_window` observations only (current observation excluded). The first
  observation of a subject has no history and receives the neutral value 0.5.
- All test-time statistics (imputation medians, score mean/std for the
  dispersion term) come from training data only.
- StatisticalBaseline cold start no longer uses the whole subject series
  (future data); it uses the training population median until history exists.
- IsolationForestDetector imputes with training medians (was test-batch medians).
- The former "model uncertainty" term is renamed a score-dispersion heuristic;
  it is not an estimate of epistemic uncertainty.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import joblib


FEATURE_COLS = ["heart_rate", "spo2", "respiratory_rate", "temperature"]

# Broad sensor-plausibility bounds used by the range-validity component.
VALIDITY_RANGES = {
    "heart_rate": (30.0, 220.0),
    "spo2": (50.0, 100.0),
    "respiratory_rate": (4.0, 60.0),
    "temperature": (33.0, 43.0),
}

EPS = 1e-6


@dataclass
class AnomalyOutput:
    """Standardized anomaly detection output."""
    scores: np.ndarray           # anomaly scores (higher = more anomalous)
    predictions: np.ndarray      # 1 anomaly, 0 normal, -1 abstain
    uncertainties: np.ndarray    # uncertainty indicator in [0, 1]
    reliability_scores: np.ndarray  # per-sample sensor reliability
    feature_contributions: Optional[list] = None  # per-sample attribution (optional)
    model_name: str = ""
    threshold: float = 0.0


def _subject_groups(df: pd.DataFrame, subject_col: str):
    """Yield (index, frame) per subject, preserving row order."""
    if subject_col in df.columns:
        for _, g in df.groupby(subject_col, sort=False):
            yield g.index, g
    else:
        yield df.index, df


# ---------------------------------------------------------------------------
# 1. Statistical baseline
# ---------------------------------------------------------------------------
class StatisticalBaseline:
    """Z-score anomaly detection against a rolling, personalized baseline.

    For each subject, every sample is compared with the rolling median of that
    subject's own preceding ``window_size`` samples. Deviations are scaled by a
    per-feature noise scale learned from training subjects. Because the baseline
    is built from each subject's own history, the model works for subjects not
    seen during training (required for subject-level train/test splits).

    The decision threshold is calibrated on training data to the expected
    contamination rate, so it is comparable to the Isolation Forest models.

    Cold start (v4): until ``min_history`` past observations exist, the
    reference value is the training-population median of the feature.
    No current or future observation is used for the reference.
    """

    def __init__(
        self,
        window_size: int = 30,
        z_threshold: Optional[float] = None,
        contamination: float = 0.05,
        min_history: int = 5,
    ):
        self.window_size = window_size
        self.z_threshold = z_threshold  # None -> calibrated during fit
        self.contamination = contamination
        self.min_history = min_history
        self.noise_scale: dict[str, float] = {}
        self.pop_median: dict[str, float] = {}
        self.name = "StatisticalBaseline"

    def _reference(self, s: pd.Series, col: str) -> pd.Series:
        past = s.shift(1)
        med = past.rolling(self.window_size, min_periods=self.min_history).median()
        return med.fillna(self.pop_median.get(col, float(np.nanmedian(s))))

    def _rolling_z(self, df: pd.DataFrame, subject_col: str) -> pd.DataFrame:
        """Absolute z-scores of each feature vs. the subject's past rolling median."""
        z = pd.DataFrame(index=df.index, columns=FEATURE_COLS, dtype=float)
        for idx, group in _subject_groups(df, subject_col):
            for col in FEATURE_COLS:
                s = group[col].astype(float)
                ref = self._reference(s, col)
                z.loc[idx, col] = ((s - ref).abs() / self.noise_scale.get(col, 1.0)).values
        return z

    def fit(self, df: pd.DataFrame, subject_col: str = "subject_id") -> None:
        """Learn per-feature noise scales and calibrate the threshold."""
        for col in FEATURE_COLS:
            self.pop_median[col] = float(df[col].median())
        residuals: dict[str, list] = {c: [] for c in FEATURE_COLS}
        for _, group in _subject_groups(df, subject_col):
            for col in FEATURE_COLS:
                s = group[col].astype(float)
                med = s.shift(1).rolling(self.window_size, min_periods=self.min_history).median()
                residuals[col].append((s - med).dropna().values)
        for col in FEATURE_COLS:
            r = np.concatenate(residuals[col]) if residuals[col] else np.array([1.0])
            mad = np.median(np.abs(r - np.median(r)))
            self.noise_scale[col] = float(max(1.4826 * mad, EPS))

        if self.z_threshold is None:
            train_scores = self._rolling_z(df, subject_col).max(axis=1, skipna=True).fillna(0).values
            self.z_threshold = float(np.quantile(train_scores, 1 - self.contamination))

    def predict(self, df: pd.DataFrame, subject_col: str = "subject_id") -> AnomalyOutput:
        """Score each row against its subject's rolling baseline."""
        n = len(df)
        z = self._rolling_z(df, subject_col)
        # Rows with every channel missing receive score 0 (cannot be scored).
        scores = z.max(axis=1, skipna=True).fillna(0).values.astype(float)
        threshold = self.z_threshold if self.z_threshold is not None else 2.5
        predictions = (scores > threshold).astype(int)
        # Uncertainty: lower for very clear anomalies, higher near threshold
        dist_from_threshold = np.abs(scores - threshold) / max(threshold, EPS)
        uncertainties = 1.0 / (1.0 + 3.0 * dist_from_threshold)
        return AnomalyOutput(
            scores=scores, predictions=predictions, uncertainties=uncertainties,
            reliability_scores=np.ones(n), model_name=self.name, threshold=threshold,
        )

    def get_params(self) -> dict:
        return {
            "window_size": self.window_size,
            "z_threshold": self.z_threshold,
            "contamination": self.contamination,
            "min_history": self.min_history,
        }


# ---------------------------------------------------------------------------
# 2. Standard Isolation Forest
# ---------------------------------------------------------------------------
class IsolationForestDetector:
    """Isolation Forest anomaly detector.

    Missing values are imputed with per-feature training medians (v4).
    The score is the bounded isolation score s = -score_samples(X) in (0, 1];
    the decision threshold is the (1 - contamination) quantile of training
    scores, i.e. the same rule used by scikit-learn's ``predict``.
    """

    def __init__(self, contamination: float = 0.05, n_estimators: int = 200,
                 random_state: int = 42):
        self.contamination = contamination
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.model = IsolationForest(contamination=contamination,
                                     n_estimators=n_estimators,
                                     random_state=random_state)
        self.scaler = StandardScaler()
        self.name = "IsolationForest"
        self._fitted = False
        self.train_median: dict[str, float] = {}
        self.threshold_: float = 0.0
        self.score_mean_: float = 0.0
        self.score_std_: float = 1.0

    def fit(self, df: pd.DataFrame) -> None:
        """Fit on complete training rows."""
        features = df[FEATURE_COLS].dropna()
        if len(features) < 10:
            raise ValueError("Need at least 10 complete rows to fit IsolationForest.")
        self.train_median = {c: float(features[c].median()) for c in FEATURE_COLS}
        X = self.scaler.fit_transform(features)
        self.model.fit(X)
        s_train = -self.model.score_samples(X)
        self.threshold_ = float(np.quantile(s_train, 1 - self.contamination))
        self.score_mean_ = float(s_train.mean())
        self.score_std_ = float(max(s_train.std(), EPS))
        self._fitted = True

    def predict(self, df: pd.DataFrame) -> AnomalyOutput:
        """Score and predict anomalies."""
        if not self._fitted:
            raise RuntimeError("Model not fitted. Call fit() first.")
        features = df[FEATURE_COLS].copy()
        missing_mask = features.isna()
        features = features.fillna(self.train_median)
        X = self.scaler.transform(features)
        scores = -self.model.score_samples(X)
        predictions = (scores > self.threshold_).astype(int)
        reliability = 1.0 - missing_mask.mean(axis=1).values
        uncertainties = np.exp(-np.abs(scores - self.score_mean_) / self.score_std_)
        return AnomalyOutput(
            scores=scores, predictions=predictions, uncertainties=uncertainties,
            reliability_scores=reliability, model_name=self.name, threshold=self.threshold_,
        )

    def save(self, path: str) -> None:
        joblib.dump(self, path)

    def load(self, path: str) -> None:
        obj = joblib.load(path)
        if not isinstance(obj, IsolationForestDetector):
            raise ValueError("Pre-v4 model file; re-run the v4 pipeline to regenerate it.")
        self.__dict__.update(obj.__dict__)

    def get_params(self) -> dict:
        return {"contamination": self.contamination, "n_estimators": self.n_estimators,
                "random_state": self.random_state}


# ---------------------------------------------------------------------------
# 3. Reliability-aware detector (HIMA-SHIELD)
# ---------------------------------------------------------------------------
class ReliabilityAwareDetector:
    """
    Proposed research contribution: Reliability-Aware Anomaly Detection.

    Hypothesis: Incorporating sensor reliability estimation into anomaly
    scoring improves interpretation when inputs are missing, noisy, or
    affected by distribution shifts.

    Approach:
    1. Estimate per-feature reliability from data quality signals
       (missingness, value range violations, temporal consistency).
    2. Weight the bounded isolation score by sample reliability.
    3. Report a degradation-responsive uncertainty indicator.
    4. Abstain when sample reliability is below a threshold.

    This is a research hypothesis, not a validated method.

    Ablation switches: ``use_completeness``, ``use_validity``, ``use_temporal``
    (remaining weights are renormalised to sum to 1), ``use_weighting``
    (if False, the unweighted score is used; abstention still applies).
    Abstention is disabled with ``abstention_threshold=0``.
    """

    def __init__(
        self,
        contamination: float = 0.05,
        abstention_threshold: float = 0.3,
        n_estimators: int = 200,
        random_state: int = 42,
        weights: tuple = (0.4, 0.3, 0.3),
        temporal_window: int = 5,
        use_completeness: bool = True,
        use_validity: bool = True,
        use_temporal: bool = True,
        use_weighting: bool = True,
        missing_temporal_value: float = 0.5,
    ):
        self.contamination = contamination
        self.abstention_threshold = abstention_threshold
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.weights = tuple(float(w) for w in weights)
        self.temporal_window = temporal_window
        self.use_completeness = use_completeness
        self.use_validity = use_validity
        self.use_temporal = use_temporal
        self.use_weighting = use_weighting
        self.missing_temporal_value = missing_temporal_value

        self.base_model = IsolationForest(contamination=contamination,
                                          n_estimators=n_estimators,
                                          random_state=random_state)
        self.scaler = StandardScaler()
        self.name = "ReliabilityAwareDetector"
        self._fitted = False
        self._training_stats: dict = {}
        self.threshold_: float = 0.0
        self.score_mean_: float = 0.0
        self.score_std_: float = 1.0

    # -- reliability ---------------------------------------------------------
    def _effective_weights(self) -> np.ndarray:
        w = np.array(self.weights, dtype=float)
        mask = np.array([self.use_completeness, self.use_validity, self.use_temporal], dtype=float)
        w = w * mask
        if w.sum() <= 0:
            raise ValueError("At least one reliability component must be enabled.")
        return w / w.sum()

    def compute_reliability(self, df: pd.DataFrame, subject_col: str = "subject_id") -> pd.DataFrame:
        """Per-channel reliability R_ij in [0, 1] (Eqs. 4-7).

        C_ij = 1 if present else 0
        V_ij = 1 if present and inside VALIDITY_RANGES else 0
        T_ij = 1 / (1 + |x_ij - median(x_{i-W..i-1, j})| / sigma_train_j),
               computed per subject from past observations only;
               missing value or no history -> missing_temporal_value (0.5)
        R_ij = wC*C + wV*V + wT*T
        """
        wC, wV, wT = self._effective_weights()
        rel = pd.DataFrame(index=df.index, columns=FEATURE_COLS, dtype=float)
        for col in FEATURE_COLS:
            x = df[col].astype(float)
            present = x.notna()
            C = present.astype(float)
            low, high = VALIDITY_RANGES[col]
            V = (present & (x >= low) & (x <= high)).astype(float)
            sigma = max(self._training_stats[col]["std"], EPS)
            T = pd.Series(np.nan, index=df.index)
            for idx, g in _subject_groups(df, subject_col):
                xs = g[col].astype(float)
                ref = xs.shift(1).rolling(self.temporal_window, min_periods=1).median()
                T.loc[idx] = (1.0 / (1.0 + (xs - ref).abs() / sigma)).values
            T = T.fillna(self.missing_temporal_value).clip(0.0, 1.0)
            rel[col] = (wC * C + wV * V + wT * T).clip(0.0, 1.0)
        return rel

    # -- fitting -------------------------------------------------------------
    def fit(self, df: pd.DataFrame, subject_col: str = "subject_id") -> None:
        """Fit the base model; calibrate threshold and dispersion stats on training data only."""
        for col in FEATURE_COLS:
            vals = df[col].dropna()
            self._training_stats[col] = {
                "mean": float(vals.mean()),
                "std": float(max(vals.std(), EPS)),
                "median": float(vals.median()),
            }
        complete = df[FEATURE_COLS].notna().all(axis=1)
        if complete.sum() < 10:
            raise ValueError("Need at least 10 complete rows.")
        train = df.loc[complete]
        X = self.scaler.fit_transform(train[FEATURE_COLS])
        self.base_model.fit(X)
        s_train = -self.base_model.score_samples(X)
        self.score_mean_ = float(s_train.mean())
        self.score_std_ = float(max(s_train.std(), EPS))
        if self.use_weighting:
            r_train = self.compute_reliability(train, subject_col).mean(axis=1).values
            ref_scores = s_train * r_train
        else:
            ref_scores = s_train
        self.threshold_ = float(np.quantile(ref_scores, 1 - self.contamination))
        self._fitted = True

    # -- inference -----------------------------------------------------------
    def predict(self, df: pd.DataFrame, subject_col: str = "subject_id") -> AnomalyOutput:
        """Reliability-weighted scoring, abstention and uncertainty (Algorithm 1)."""
        if not self._fitted:
            raise RuntimeError("Model not fitted.")
        rel = self.compute_reliability(df, subject_col)
        r_sample = rel.mean(axis=1).values                      # Eq. 8
        feats = df[FEATURE_COLS].astype(float).fillna(
            {c: self._training_stats[c]["median"] for c in FEATURE_COLS})
        X = self.scaler.transform(feats)
        s_raw = -self.base_model.score_samples(X)              # Eq. 3, in (0, 1]
        s = s_raw * r_sample if self.use_weighting else s_raw  # Eq. 9

        predictions = np.where(s > self.threshold_, 1, 0)      # Eq. 11
        predictions = np.where(r_sample < self.abstention_threshold, -1, predictions)

        u_data = 1.0 - r_sample                                 # Eq. 12
        u_disp = np.exp(-np.abs(s_raw - self.score_mean_) / self.score_std_)  # Eq. 13
        u_total = np.clip(0.5 * u_data + 0.5 * u_disp, 0.0, 1.0)  # Eq. 14

        return AnomalyOutput(
            scores=s, predictions=predictions.astype(int), uncertainties=u_total,
            reliability_scores=r_sample, model_name=self.name, threshold=self.threshold_,
        )

    def save(self, path: str) -> None:
        joblib.dump(self, path)

    def load(self, path: str) -> None:
        obj = joblib.load(path)
        if not isinstance(obj, ReliabilityAwareDetector):
            raise ValueError("Pre-v4 model file; re-run the v4 pipeline to regenerate it.")
        self.__dict__.update(obj.__dict__)

    def get_params(self) -> dict:
        return {
            "contamination": self.contamination,
            "abstention_threshold": self.abstention_threshold,
            "n_estimators": self.n_estimators,
            "random_state": self.random_state,
            "weights": self.weights,
            "temporal_window": self.temporal_window,
            "use_completeness": self.use_completeness,
            "use_validity": self.use_validity,
            "use_temporal": self.use_temporal,
            "use_weighting": self.use_weighting,
        }
