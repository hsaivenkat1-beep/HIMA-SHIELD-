"""
v5 figure generator: regenerate all main + supplementary figures from v5 results.
"""
import sys, os, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from scipy import stats

warnings.filterwarnings("ignore")

BRAIN = r"C:\Users\hsaiv\.gemini\antigravity\brain\49d21d80-3fde-47b1-b6a4-fe539ba2c4ce"
R = os.path.join(BRAIN, "results_v5")
FM = os.path.join(BRAIN, "figures_v5")
FS = os.path.join(BRAIN, "figures_supplementary_v5")
os.makedirs(FM, exist_ok=True)
os.makedirs(FS, exist_ok=True)

per = pd.read_csv(os.path.join(R, "per_seed_metrics.csv"))
agg = pd.read_csv(os.path.join(R, "aggregated_metrics.csv"))
abl = pd.read_csv(os.path.join(R, "ablation_metrics.csv"))
st = pd.read_csv(os.path.join(R, "statistical_tests.csv"))
supp = pd.read_csv(os.path.join(R, "suppression_audit.csv"))
mech = pd.read_csv(os.path.join(R, "reliability_mechanism.csv"))
det = pd.read_csv(os.path.join(R, "per_sample_seed42.csv"))
lat = pd.read_csv(os.path.join(R, "latency_report.csv")).set_index("model")
ct = pd.read_csv(os.path.join(R, "clean_training_comparison.csv"))
sp = pd.read_csv(os.path.join(R, "subject_partitions.csv"))
s_theta = pd.read_csv(os.path.join(R, "sensitivity_theta.csv"))
s_win = pd.read_csv(os.path.join(R, "sensitivity_window.csv"))
s_wt = pd.read_csv(os.path.join(R, "sensitivity_weights.csv"))

SC = ["clean", "missing_10pct", "missing_30pct", "burst_missing", "noise", "bias_drift", "combined"]
SCL = {"clean": "Clean", "missing_10pct": "Miss 10%", "missing_30pct": "Miss 30%",
       "burst_missing": "Burst miss", "noise": "Noise", "bias_drift": "Bias drift", "combined": "Combined"}
MODELS = ["SB", "IF", "RA"]
COLORS = {"SB": "#2196F3", "IF": "#4CAF50", "RA": "#F44336"}
N = int(per.seed.nunique())

def g(sc, mo, col, stat="mean"):
    return float(agg[(agg.scenario==sc)&(agg.model==mo)][f"{col}_{stat}"].iloc[0])

# ---- Fig 1: F1 comparison (MAIN) ----
fig, ax = plt.subplots(figsize=(10, 5))
x = np.arange(len(SC))
w = 0.25
for i, m in enumerate(MODELS):
    means = [g(s, m, "sel_f1") for s in SC]
    cis = [g(s, m, "sel_f1", "ci95") for s in SC]
    ax.bar(x + i*w, means, w, yerr=cis, label=m, color=COLORS[m], capsize=3, edgecolor="white")
ax.set_xticks(x + w)
ax.set_xticklabels([SCL[s] for s in SC], rotation=30, ha="right", fontsize=9)
ax.set_ylabel("Selective F1 (mean +/- 95% CI)", fontsize=10)
ax.set_title(f"Figure 1. Detection performance across corruption scenarios (n={N} seeds)", fontsize=11)
ax.legend(fontsize=9)
ax.set_ylim(0, 1.1)
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FM, "fig1_f1_comparison.png"), dpi=200)
fig.savefig(os.path.join(FM, "fig1_f1_comparison.pdf"))
plt.close()
print("Fig 1 done")

# ---- Fig 2: ROC curves seed 42 (MAIN) ----
from sklearn.metrics import roc_curve, auc as sk_auc
d42c = det[det.scenario == "clean"]
fig, ax = plt.subplots(figsize=(6, 5))
for m in MODELS:
    fpr, tpr, _ = roc_curve(d42c.true_label, d42c[f"{m}_score"])
    a = sk_auc(fpr, tpr)
    ax.plot(fpr, tpr, label=f"{m} (AUC={a:.3f})", color=COLORS[m], lw=2)
ax.plot([0,1],[0,1], "k--", lw=0.8, alpha=0.5)
ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
ax.set_title("Figure 2. ROC curves, clean data, seed 42\n(illustrative run, outside 20-seed evaluation)", fontsize=10)
ax.legend(fontsize=9); ax.grid(alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FM, "fig2_roc.png"), dpi=200)
fig.savefig(os.path.join(FM, "fig2_roc.pdf"))
plt.close()
print("Fig 2 done")

# ---- Fig 3: PR curves seed 42 (MAIN) ----
from sklearn.metrics import precision_recall_curve, average_precision_score
fig, ax = plt.subplots(figsize=(6, 5))
for m in MODELS:
    prec, rec, _ = precision_recall_curve(d42c.true_label, d42c[f"{m}_score"])
    ap = average_precision_score(d42c.true_label, d42c[f"{m}_score"])
    ax.plot(rec, prec, label=f"{m} (AP={ap:.3f})", color=COLORS[m], lw=2)
ax.set_xlabel("Recall"); ax.set_ylabel("Precision")
ax.set_title("Figure 3. Precision-recall curves, clean data, seed 42\n(illustrative run, outside 20-seed evaluation)", fontsize=10)
ax.legend(fontsize=9); ax.grid(alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FM, "fig3_pr.png"), dpi=200)
fig.savefig(os.path.join(FM, "fig3_pr.pdf"))
plt.close()
print("Fig 3 done")

# ---- Fig 4: Risk-coverage seed 42 (MAIN) ----
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
for ax, scen, title in zip(axes, ["clean", "missing_30pct"], ["Clean", "30% missing"]):
    d = det[det.scenario == scen]
    y = d.true_label.values
    for m, col_score, col_rel in [("RA", "RA_score", "RA_rel"), ("IF", "IF_score", "IF_rel")]:
        rel = d[col_rel].values
        scores = d[col_score].values
        preds_raw = d[f"{m}_pred"].values
        # Sort by decreasing reliability
        order = np.argsort(-rel)
        cum_err = np.cumsum((np.where(preds_raw[order]==-1, 0, preds_raw[order]) != y[order]).astype(float))
        n_pts = np.arange(1, len(order)+1)
        risk = cum_err / n_pts
        coverage = n_pts / len(order)
        ax.plot(coverage, risk, label=f"{m} (by reliability)", color=COLORS[m], lw=1.5)
    ax.set_xlabel("Coverage"); ax.set_ylabel("Selective risk (error rate)")
    ax.set_title(f"{title}", fontsize=10)
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
fig.suptitle("Figure 4. Risk-coverage curves, seed 42 (illustrative)", fontsize=11, y=1.02)
plt.tight_layout()
fig.savefig(os.path.join(FM, "fig4_risk_coverage.png"), dpi=200, bbox_inches="tight")
fig.savefig(os.path.join(FM, "fig4_risk_coverage.pdf"), bbox_inches="tight")
plt.close()
print("Fig 4 done")

# ======== SUPPLEMENTARY FIGURES ========

# S1: Radar chart
from math import pi
fig, ax = plt.subplots(figsize=(7,7), subplot_kw=dict(polar=True))
metrics_r = ["sel_f1", "sel_precision", "sel_recall", "sel_specificity", "full_auroc"]
labels_r = ["F1", "Precision", "Recall", "Specificity", "AUROC"]
angles = [n / float(len(labels_r)) * 2 * pi for n in range(len(labels_r))]
angles += angles[:1]
for m in MODELS:
    vals = [g("clean", m, met) for met in metrics_r]
    vals += vals[:1]
    ax.plot(angles, vals, "o-", label=m, color=COLORS[m], lw=2)
    ax.fill(angles, vals, alpha=0.1, color=COLORS[m])
ax.set_xticks(angles[:-1]); ax.set_xticklabels(labels_r)
ax.set_title(f"Figure S1. Multi-metric radar, clean data (n={N} seeds)", fontsize=10)
ax.legend(loc="upper right", fontsize=9)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS1_radar.png"), dpi=200)
plt.close()
print("S1 done")

# S2: F1 degradation
fig, ax = plt.subplots(figsize=(10, 5))
for m in MODELS:
    means = [g(s, m, "sel_f1") for s in SC]
    cis = [g(s, m, "sel_f1", "ci95") for s in SC]
    ax.errorbar(range(len(SC)), means, yerr=cis, label=m, color=COLORS[m], marker="o", capsize=4, lw=2)
ax.set_xticks(range(len(SC))); ax.set_xticklabels([SCL[s] for s in SC], rotation=30, ha="right")
ax.set_ylabel("Selective F1"); ax.set_title(f"Figure S2. F1 degradation across scenarios (n={N} seeds)")
ax.legend(); ax.grid(alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS2_f1_degradation.png"), dpi=200)
plt.close()
print("S2 done")

# S3: AUROC
fig, ax = plt.subplots(figsize=(10, 5))
for m in MODELS:
    means = [g(s, m, "full_auroc") for s in SC]
    cis = [g(s, m, "full_auroc", "ci95") for s in SC]
    ax.errorbar(range(len(SC)), means, yerr=cis, label=m, color=COLORS[m], marker="s", capsize=4, lw=2)
ax.set_xticks(range(len(SC))); ax.set_xticklabels([SCL[s] for s in SC], rotation=30, ha="right")
ax.set_ylabel("AUROC"); ax.set_title(f"Figure S3. AUROC across scenarios (n={N} seeds)")
ax.legend(); ax.grid(alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS3_auroc.png"), dpi=200)
plt.close()
print("S3 done")

# S4: Latency
fig, ax = plt.subplots(figsize=(6, 4))
models_lat = ["SB", "IF", "RA"]
vals = [lat.loc[m, "per_obs_mean_ms"]*1000 for m in models_lat]  # microseconds
ax.bar(models_lat, vals, color=[COLORS[m] for m in models_lat], edgecolor="white")
ax.set_ylabel("Latency per observation (microseconds)")
ax.set_title("Figure S4. Batch inference latency")
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS4_latency.png"), dpi=200)
plt.close()
print("S4 done")

# S5: Ablation
fig, ax = plt.subplots(figsize=(8, 5))
abl_order = ["IF_baseline", "full", "no_completeness", "no_validity", "no_temporal", "no_weighting", "no_abstention"]
abl_labels = ["IF (no reliability)", "Full RA", "No completeness", "No validity", "No temporal", "No weighting", "No abstention"]
for i, (cfg, lab) in enumerate(zip(abl_order, abl_labels)):
    d = abl[abl.ablation == cfg]
    ax.barh(i, d.sel_f1.mean(), xerr=stats.t.ppf(0.975, len(d)-1)*d.sel_f1.std()/np.sqrt(len(d)),
            color="#4CAF50" if cfg == "IF_baseline" else "#F44336", capsize=3, edgecolor="white")
ax.set_yticks(range(len(abl_labels))); ax.set_yticklabels(abl_labels)
ax.set_xlabel("Selective F1"); ax.set_title(f"Figure S5. Component ablation, clean data (n={N} seeds)")
ax.grid(axis="x", alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS5_ablation.png"), dpi=200)
plt.close()
print("S5 done")

# S6: Uncertainty vs error (descriptive)
d42m = det[det.scenario == "missing_30pct"]
fig, ax = plt.subplots(figsize=(6, 5))
err = (np.where(d42m.RA_pred == -1, 0, d42m.RA_pred) != d42m.true_label).astype(int)
bins = np.linspace(0, 1, 11)
digitized = np.digitize(d42m.RA_unc.values, bins)
for b in range(1, len(bins)):
    mask = digitized == b
    if mask.sum() > 0:
        ax.bar(bins[b-1], err[mask].mean(), width=0.08, color="#F44336", alpha=0.7, edgecolor="white")
ax.set_xlabel("Uncertainty indicator"); ax.set_ylabel("Error rate")
ax.set_title("Figure S6. Error rate by uncertainty bin, seed 42, 30% missing\n(descriptive only, not a calibration claim)")
ax.grid(alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS6_unc_vs_error.png"), dpi=200)
plt.close()
print("S6 done")

# S7: Clean-training comparison (NEW)
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
for ax, scen, title in zip(axes, ["clean", "missing_30pct"], ["Clean data", "30% missing"]):
    for i, m in enumerate(MODELS):
        for j, mode in enumerate(["contaminated", "clean"]):
            d = ct[(ct.training_mode==mode)&(ct.scenario==scen)&(ct.model==m)]
            offset = j * 0.15
            color = COLORS[m] if mode == "contaminated" else "white"
            edge = COLORS[m]
            ax.bar(i + offset, d.sel_f1.mean(), 0.13,
                   yerr=stats.t.ppf(0.975, len(d)-1)*d.sel_f1.std()/np.sqrt(len(d)),
                   color=color, edgecolor=edge, capsize=3, lw=1.5)
    ax.set_xticks([0.075, 1.075, 2.075])
    ax.set_xticklabels(MODELS)
    ax.set_ylabel("Selective F1"); ax.set_title(title)
    ax.set_ylim(0, 1.1); ax.grid(axis="y", alpha=0.3)
handles = [Patch(facecolor="gray", edgecolor="gray", label="Contaminated training"),
           Patch(facecolor="white", edgecolor="gray", label="Clean training")]
axes[0].legend(handles=handles, fontsize=8)
fig.suptitle(f"Figure S7. Clean vs contaminated training (n={N} seeds)", fontsize=11)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS7_clean_training.png"), dpi=200)
plt.close()
print("S7 done")

# S8: Theta sensitivity with coverage
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
for ax, scen, title in zip(axes, ["clean", "missing_30pct"], ["Clean", "30% missing"]):
    d = s_theta[s_theta.scenario == scen].groupby("theta").mean(numeric_only=True)
    ax.plot(d.index, d.sel_f1, "o-", color="#F44336", label="Selective F1", lw=2)
    ax.plot(d.index, d.full_f1, "s--", color="#9C27B0", label="Full-coverage F1", lw=2)
    ax2 = ax.twinx()
    ax2.plot(d.index, d.coverage, "^-", color="#2196F3", label="Coverage", lw=1.5, alpha=0.7)
    ax2.set_ylabel("Coverage", color="#2196F3")
    ax.set_xlabel("Abstention threshold (theta)"); ax.set_ylabel("F1")
    ax.set_title(title); ax.legend(loc="upper left", fontsize=8); ax2.legend(loc="upper right", fontsize=8)
    ax.grid(alpha=0.3)
fig.suptitle(f"Figure S8. Abstention threshold sensitivity (n={N} seeds)", fontsize=11)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS8_sensitivity.png"), dpi=200)
plt.close()
print("S8 done")

# S9: Confusion matrices seed 42
from sklearn.metrics import ConfusionMatrixDisplay
fig, axes = plt.subplots(2, 3, figsize=(14, 9))
for row, scen in enumerate(["clean", "missing_30pct"]):
    d = det[det.scenario == scen]
    for col_i, m in enumerate(MODELS):
        ax = axes[row, col_i]
        y = d.true_label.values
        p = d[f"{m}_pred"].values
        p_binary = np.where(p == -1, 0, p)
        n_abs = (p == -1).sum()
        n_abs_a = ((p == -1) & (y == 1)).sum()
        cm = np.array([[((p_binary==0)&(y==0)).sum(), ((p_binary==1)&(y==0)).sum()],
                       [((p_binary==0)&(y==1)).sum(), ((p_binary==1)&(y==1)).sum()]])
        ConfusionMatrixDisplay(cm, display_labels=["Normal","Anomaly"]).plot(ax=ax, cmap="Blues", colorbar=False)
        ax.set_title(f"{SCL[scen]} | {m}\nAbstained: {n_abs} ({n_abs_a} anomalies)", fontsize=9)
fig.suptitle("Figure S9. Confusion matrices, seed 42 (illustrative, outside 20-seed set)", fontsize=11)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS9_confusion.png"), dpi=200)
plt.close()
print("S9 done")

# S10: Suppression audit
sg = supp.groupby("scenario").mean(numeric_only=True)
fig, ax = plt.subplots(figsize=(10, 5))
x = np.arange(len(SC))
ax.bar(x - 0.15, [sg.loc[s, "ra_fn_misclassified_normal"] for s in SC], 0.3, label="Misclassified as normal", color="#F44336")
ax.bar(x + 0.15, [sg.loc[s, "ra_fn_abstained"] for s in SC], 0.3, label="Abstained", color="#FF9800")
ax.set_xticks(x); ax.set_xticklabels([SCL[s] for s in SC], rotation=30, ha="right")
ax.set_ylabel("Anomalies missed by RA (mean per seed)")
ax.set_title(f"Figure S10. How RA misses anomalies: misclassification vs abstention (n={N} seeds)")
ax.legend(); ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS10_suppression.png"), dpi=200)
plt.close()
print("S10 done")

# S11: Subject partition variability (NEW)
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
for ax, scen, title in zip(axes, ["clean", "missing_30pct"], ["Clean", "30% missing"]):
    d = sp[sp.scenario == scen]
    for m in MODELS:
        dm = d[d.model == m]
        ax.boxplot([dm[dm.seed==s].sel_f1.values for s in [1,5,10,15,20]],
                   positions=[MODELS.index(m)*6 + i for i in range(5)],
                   widths=0.6, patch_artist=True,
                   boxprops=dict(facecolor=COLORS[m], alpha=0.5))
    ax.set_title(title)
    ax.set_ylabel("Selective F1")
    ticks = [1*6+2, 0*6+2, 2*6+2]
    ax.set_xticks([m_i*6+2 for m_i in range(3)])
    ax.set_xticklabels(MODELS)
    ax.grid(axis="y", alpha=0.3)
fig.suptitle(f"Figure S11. Subject-partition variability (5 partitions x 5 seeds)", fontsize=11)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS11_partitions.png"), dpi=200)
plt.close()
print("S11 done")

# S12: Weight sensitivity (NEW)
fig, ax = plt.subplots(figsize=(8, 5))
wt_order = ["default", "high_C", "high_V", "high_T", "equal", "dominant_C", "dominant_T"]
wt_labels = ["Default\n(0.4/0.3/0.3)", "High C\n(0.5/0.25/0.25)", "High V\n(0.25/0.5/0.25)",
             "High T\n(0.25/0.25/0.5)", "Equal\n(0.33/0.33/0.34)", "Dom. C\n(0.6/0.2/0.2)", "Dom. T\n(0.2/0.2/0.6)"]
for i, (cfg, lab) in enumerate(zip(wt_order, wt_labels)):
    d = s_wt[s_wt.weight_config == cfg]
    color = "#F44336" if "T" in cfg.upper() and cfg != "default" else "#4CAF50"
    ax.bar(i, d.sel_f1.mean(), yerr=d.sel_f1.std(), color=color, capsize=3, edgecolor="white")
ax.set_xticks(range(len(wt_labels))); ax.set_xticklabels(wt_labels, fontsize=8)
ax.set_ylabel("Selective F1"); ax.set_title("Figure S12. Reliability-weight sensitivity, clean data (n=20 seeds)")
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(FS, "figS12_weights.png"), dpi=200)
plt.close()
print("S12 done")

print("\nAll figures generated.")
