"""
HIMA-SHIELD Experiment Runner.

Runs controlled experiments comparing all models under clean and corrupted
conditions. Produces metrics.json with reproducible results.

Corruption types:
- missing: Random missing values
- burst_missing: Contiguous blocks of missing data
- noise: Added Gaussian noise
- bias: Systematic sensor bias/drift
- combined: Multiple corruptions simultaneously

All corruptions are clearly labeled as SYNTHETIC/SIMULATED.
"""
from __future__ import annotations

import json
import time
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
)

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from data_generator import generate_dataset, inject_anomalies
from models import (
    StatisticalBaseline,
    IsolationForestDetector,
    ReliabilityAwareDetector,
    FEATURE_COLS,
    AnomalyOutput,
)


def apply_corruption(
    df: pd.DataFrame,
    corruption_type: str,
    fraction: float = 0.1,
    seed: int = 99,
) -> pd.DataFrame:
    """Apply synthetic corruption to data.

    Args:
        df: Input DataFrame.
        corruption_type: One of 'missing', 'burst_missing', 'noise', 'bias', 'combined'.
        fraction: Fraction of data affected.
        seed: Random seed.

    Returns:
        Corrupted DataFrame (copy).
    """
    rng = np.random.default_rng(seed)
    df = df.copy()
    n = len(df)
    n_affected = max(1, int(n * fraction))

    if corruption_type == "missing":
        for col in FEATURE_COLS:
            mask = rng.choice(n, size=n_affected, replace=False)
            df.loc[df.index[mask], col] = np.nan

    elif corruption_type == "burst_missing":
        # Multiple contiguous sensor dropouts (e.g. loose probe) in HR and SpO2,
        # repeated until roughly `fraction` of each column is missing.
        burst_len = 20
        for col in FEATURE_COLS[:2]:  # HR and SpO2
            missing = np.zeros(n, dtype=bool)
            while missing.sum() < n_affected:
                start = int(rng.integers(0, max(1, n - burst_len)))
                missing[start:start + burst_len] = True
            df.loc[df.index[missing], col] = np.nan

    elif corruption_type == "noise":
        noise_std = {"heart_rate": 15, "spo2": 5, "respiratory_rate": 5, "temperature": 1}
        indices = rng.choice(n, size=n_affected, replace=False)
        for col in FEATURE_COLS:
            if col in df.columns:
                noise = rng.normal(0, noise_std.get(col, 5), n_affected)
                df.loc[df.index[indices], col] += noise

    elif corruption_type == "bias":
        bias_vals = {"heart_rate": 20, "spo2": -8, "respiratory_rate": 5, "temperature": 0.8}
        # Apply drift starting from a random point
        start = rng.integers(0, max(1, n // 2))
        for col in FEATURE_COLS:
            if col in df.columns:
                drift = np.linspace(0, bias_vals.get(col, 5), n - start)
                df.loc[df.index[start:], col] += drift

    elif corruption_type == "combined":
        df = apply_corruption(df, "missing", fraction * 0.5, seed)
        df = apply_corruption(df, "noise", fraction * 0.5, seed + 1)

    return df


def evaluate_model(
    output: AnomalyOutput,
    true_labels: np.ndarray,
) -> dict:
    """Compute evaluation metrics."""
    # For models with abstention, evaluate only non-abstained samples
    mask = output.predictions != -1
    if mask.sum() == 0:
        return {"error": "All samples abstained", "coverage": 0.0}

    preds = output.predictions[mask]
    true = true_labels[mask]
    scores = output.scores[mask]

    metrics = {
        "coverage": float(mask.mean()),
        "n_evaluated": int(mask.sum()),
        "n_abstained": int((~mask).sum()),
    }

    # Only compute if we have both classes
    if len(np.unique(true)) >= 2 and len(np.unique(preds)) >= 1:
        metrics["precision"] = round(float(precision_score(true, preds, zero_division=0)), 4)
        metrics["recall"] = round(float(recall_score(true, preds, zero_division=0)), 4)
        metrics["f1"] = round(float(f1_score(true, preds, zero_division=0)), 4)

        try:
            metrics["auroc"] = round(float(roc_auc_score(true, scores)), 4)
        except ValueError:
            metrics["auroc"] = None

        try:
            metrics["auprc"] = round(float(average_precision_score(true, scores)), 4)
        except ValueError:
            metrics["auprc"] = None

        cm = confusion_matrix(true, preds, labels=[0, 1])
        metrics["confusion_matrix"] = cm.tolist()
        if cm.shape == (2, 2):
            metrics["true_negatives"] = int(cm[0, 0])
            metrics["false_positives"] = int(cm[0, 1])
            metrics["false_negatives"] = int(cm[1, 0])
            metrics["true_positives"] = int(cm[1, 1])
    else:
        metrics["note"] = "Insufficient class diversity for classification metrics"

    # Uncertainty calibration
    metrics["mean_uncertainty"] = round(float(np.mean(output.uncertainties)), 4)
    metrics["mean_reliability"] = round(float(np.mean(output.reliability_scores)), 4)

    return metrics


def run_experiments(
    output_dir: str = "./ml/experiments",
    data_dir: str = "./data/processed",
    n_subjects: int = 10,
    samples_per_subject: int = 500,
    seed: int = 42,
) -> dict:
    """Run the full experiment suite.

    1. Generate synthetic data
    2. Inject anomalies
    3. Split by subject (no leakage)
    4. Train models on training set
    5. Evaluate on clean and corrupted test sets
    6. Save metrics.json

    Returns:
        Complete metrics dictionary.
    """
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("HIMA-SHIELD Experiment Suite")
    print("=" * 60)

    # Step 1: Generate data
    print("\n[1/6] Generating synthetic dataset...")
    dataset = generate_dataset(
        n_subjects=n_subjects,
        samples_per_subject=samples_per_subject,
        base_seed=seed,
        output_dir=data_dir,
    )
    print(f"  Generated {len(dataset)} rows, {dataset['subject_id'].nunique()} subjects")

    # Step 2: Inject anomalies
    print("\n[2/6] Injecting synthetic anomalies...")
    dataset, anomaly_labels = inject_anomalies(dataset, anomaly_fraction=0.05, seed=seed + 100)
    print(f"  Injected {anomaly_labels.sum()} anomalies ({anomaly_labels.mean()*100:.1f}%)")

    # Step 3: Subject-level train/test split (no leakage)
    print("\n[3/6] Splitting data by subject...")
    # Convert to a plain numpy array: pandas>=3 returns an ArrowStringArray,
    # which numpy cannot shuffle safely (may duplicate entries -> leakage).
    subjects = np.array(sorted(dataset["subject_id"].astype(str).unique()), dtype=object)
    rng = np.random.default_rng(seed)
    rng.shuffle(subjects)
    split_idx = int(len(subjects) * 0.7)
    train_subjects = [str(s) for s in subjects[:split_idx]]
    test_subjects = [str(s) for s in subjects[split_idx:]]
    assert not set(train_subjects) & set(test_subjects), "Subject leakage between splits"
    assert len(set(train_subjects)) + len(set(test_subjects)) == len(subjects)

    train_mask = dataset["subject_id"].isin(train_subjects)
    test_mask = dataset["subject_id"].isin(test_subjects)

    train_df = dataset[train_mask].copy()
    test_df = dataset[test_mask].copy()
    test_labels = anomaly_labels[test_mask].values.astype(int)

    print(f"  Train: {len(train_df)} rows ({len(train_subjects)} subjects)")
    print(f"  Test:  {len(test_df)} rows ({len(test_subjects)} subjects)")
    print(f"  Test anomalies: {test_labels.sum()} ({test_labels.mean()*100:.1f}%)")

    # Step 4: Initialize and train models
    print("\n[4/6] Training models...")

    models = {
        "statistical_baseline": StatisticalBaseline(window_size=30, contamination=0.05),
        "isolation_forest": IsolationForestDetector(
            contamination=0.05, n_estimators=200, random_state=seed
        ),
        "reliability_aware": ReliabilityAwareDetector(
            contamination=0.05,
            abstention_threshold=0.3,
            n_estimators=200,
            random_state=seed,
        ),
    }

    for name, model in models.items():
        print(f"  Training {name}...")
        t0 = time.time()
        if hasattr(model, "fit"):
            if name == "statistical_baseline":
                model.fit(train_df)
            else:
                model.fit(train_df)
        elapsed = time.time() - t0
        print(f"    Done in {elapsed:.2f}s")

    # Step 5: Evaluate on clean and corrupted test sets
    print("\n[5/6] Evaluating models...")

    corruption_scenarios = {
        "clean": None,
        "missing_10pct": ("missing", 0.1),
        "missing_30pct": ("missing", 0.3),
        "burst_missing": ("burst_missing", 0.15),
        "noise": ("noise", 0.2),
        "bias_drift": ("bias", 0.1),
        "combined": ("combined", 0.15),
    }

    all_results = {}
    for scenario_name, corruption_spec in corruption_scenarios.items():
        print(f"\n  Scenario: {scenario_name}")

        if corruption_spec is None:
            eval_df = test_df.copy()
        else:
            c_type, c_frac = corruption_spec
            eval_df = apply_corruption(test_df, c_type, c_frac, seed=seed + 200)

        scenario_results = {}
        for model_name, model in models.items():
            t0 = time.time()
            output = model.predict(eval_df)
            latency = time.time() - t0

            metrics = evaluate_model(output, test_labels)
            metrics["inference_latency_seconds"] = round(latency, 4)
            metrics["model_params"] = model.get_params()

            scenario_results[model_name] = metrics
            f1 = metrics.get("f1", "N/A")
            cov = metrics.get("coverage", 1.0)
            print(f"    {model_name}: F1={f1}, Coverage={cov:.2f}")

        all_results[scenario_name] = scenario_results

    # Step 6: Save results
    print("\n[6/6] Saving results...")

    experiment_metadata = {
        "experiment_name": "HIMA-SHIELD Baseline Comparison",
        "description": (
            "Comparison of anomaly detection models on synthetic high-altitude "
            "physiological data with controlled corruption scenarios. "
            "All data is SYNTHETIC — results demonstrate pipeline functionality."
        ),
        "timestamp": datetime.now().isoformat(),
        "data_type": "SYNTHETIC",
        "dataset": {
            "n_subjects": n_subjects,
            "samples_per_subject": samples_per_subject,
            "total_rows": len(dataset),
            "anomaly_fraction": 0.05,
            "train_subjects": list(train_subjects),
            "test_subjects": list(test_subjects),
        },
        "random_seed": seed,
        "models": {name: model.get_params() for name, model in models.items()},
        "corruption_scenarios": {
            k: {"type": v[0], "fraction": v[1]} if v else "none"
            for k, v in corruption_scenarios.items()
        },
        "results": all_results,
        "disclaimer": (
            "These results are from SYNTHETIC data generated for demonstration. "
            "They do not represent clinical performance or real-world validation."
        ),
    }

    metrics_path = out_path / "metrics.json"
    with open(metrics_path, "w") as f:
        json.dump(experiment_metadata, f, indent=2, default=str)
    print(f"  Saved metrics to {metrics_path}")

    # Save models
    models_dir = Path("./ml/models")
    models_dir.mkdir(parents=True, exist_ok=True)

    models["isolation_forest"].save(str(models_dir / "isolation_forest.joblib"))
    models["reliability_aware"].save(str(models_dir / "reliability_aware.joblib"))
    print(f"  Saved models to {models_dir}")

    print("\n" + "=" * 60)
    print("Experiments complete!")
    print("=" * 60)

    return experiment_metadata


if __name__ == "__main__":
    results = run_experiments()
