"""
Build HIMA-SHIELD v5 manuscript (main + SI) as Markdown.
Every number read from results_v5/*.csv. Zero hand-typed results.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import spearmanr

BRAIN = Path(r"C:\Users\hsaiv\.gemini\antigravity\brain\49d21d80-3fde-47b1-b6a4-fe539ba2c4ce")
R = BRAIN / "results_v5"
F = (BRAIN / "figures_v5").as_posix()
FS = (BRAIN / "figures_supplementary_v5").as_posix()

agg = pd.read_csv(R / "aggregated_metrics.csv")
per = pd.read_csv(R / "per_seed_metrics.csv")
st = pd.read_csv(R / "statistical_tests.csv")
abl = pd.read_csv(R / "ablation_metrics.csv")
ct = pd.read_csv(R / "clean_training_comparison.csv")
sp = pd.read_csv(R / "subject_partitions.csv")
supp = pd.read_csv(R / "suppression_audit.csv")
mech = pd.read_csv(R / "reliability_mechanism.csv")
s_theta = pd.read_csv(R / "sensitivity_theta.csv")
s_win = pd.read_csv(R / "sensitivity_window.csv")
s_wt = pd.read_csv(R / "sensitivity_weights.csv")
lat = pd.read_csv(R / "latency_report.csv").set_index("model")
man = json.load(open(R / "run_manifest.json"))
det = pd.read_csv(R / "per_sample_seed42.csv")

SC = ["clean", "missing_10pct", "missing_30pct", "burst_missing", "noise", "bias_drift", "combined"]
SCL = {"clean": "Clean", "missing_10pct": "Random missing 10%", "missing_30pct": "Random missing 30%",
       "burst_missing": "Burst missing (HR, SpO2)", "noise": "Gaussian noise (20% rows)",
       "bias_drift": "Linear bias drift", "combined": "Combined (missing + noise)"}
N = int(per.seed.nunique())
TC = stats.t.ppf(0.975, N - 1)


def g(sc, mo, col, stat="mean"):
    return float(agg[(agg.scenario == sc) & (agg.model == mo)][f"{col}_{stat}"].iloc[0])

def mci(sc, mo, col, d=3):
    return f"{g(sc, mo, col):.{d}f} +/- {g(sc, mo, col, 'ci95'):.{d}f}"

def tci(x, d=3):
    x = np.asarray(x, float)
    return f"{x.mean():.{d}f} +/- {TC * x.std(ddof=1) / np.sqrt(len(x)):.{d}f}"

def best(sc, col="sel_f1"):
    return max(["SB", "IF", "RA"], key=lambda m: g(sc, m, col))

def fmt_p(p):
    return "< 0.001" if p < 0.001 else f"{p:.3f}"

# ---- derived numbers ----
n_anom = per.drop_duplicates("seed").n_test_anomalies
ra_beats_if = [s for s in SC if g(s, "RA", "sel_f1") > g(s, "IF", "sel_f1")]
sb_best = [s for s in SC if best(s) == "SB"]
nb_win = len(ra_beats_if)

m_agg = mech.groupby("scenario").mean(numeric_only=True)
ab = abl.groupby("ablation")
def abm(cfg, col): return tci(abl[abl.ablation == cfg][col])

sp_agg = supp.groupby("scenario").mean(numeric_only=True)

# Clean training comparison
ct_clean = ct[ct.training_mode == "clean"]
ct_contam = ct[ct.training_mode == "contaminated"]

def ct_f1(mode, scen, model):
    d = ct[(ct.training_mode == mode) & (ct.scenario == scen) & (ct.model == model)]
    return f"{d.sel_f1.mean():.3f} +/- {TC * d.sel_f1.std() / np.sqrt(len(d)):.3f}"

# Subject partition variability
sp_std = {}
for scen in ["clean", "missing_30pct"]:
    for m in ["SB", "IF", "RA"]:
        d = sp[(sp.scenario == scen) & (sp.model == m)]
        sp_std[f"{scen}_{m}"] = f"{d.sel_f1.mean():.3f} (SD {d.sel_f1.std():.3f}, range {d.sel_f1.min():.3f}-{d.sel_f1.max():.3f})"

# Theta sensitivity
s30 = s_theta[s_theta.scenario == "missing_30pct"].groupby("theta").mean(numeric_only=True)

# Window sensitivity
sw_agg = s_win.groupby("temporal_window").mean(numeric_only=True)

# Weight sensitivity
swt_agg = s_wt.groupby("weight_config").mean(numeric_only=True)

# Seed 42 uncertainty correlations
d42m = det[det.scenario == "missing_30pct"]
err42 = (np.where(d42m.RA_pred == -1, 0, d42m.RA_pred) != d42m.true_label).astype(int)
rho_u, p_u = spearmanr(d42m.RA_unc, err42)
d42c = det[det.scenario == "clean"]
err42c = (d42c.RA_pred != d42c.true_label).astype(int)
rho_uc, p_uc = spearmanr(d42c.RA_unc, err42c)

pv = man["package_versions"]

def stat_row(sc, comp):
    return st[(st.scenario == sc) & (st.comparison == comp)].iloc[0]

# ---------- Tables ----------
def table_main():
    lines = ["| Scenario | SB F1 | IF F1 | RA F1 | RA - IF diff (d, W, p_Holm) | RA coverage | RA abstained (anomalies) |",
             "|---|---|---|---|---|---|---|"]
    for s in SC:
        r = stat_row(s, "RA_vs_IF")
        lines.append(f"| {SCL[s]} | {mci(s,'SB','sel_f1')} | {mci(s,'IF','sel_f1')} | {mci(s,'RA','sel_f1')} | "
                     f"{r.diff_mean:+.3f} (d={r.cohens_d:+.1f}, W={r.W_statistic:.0f}, {fmt_p(r.p_holm)}) | {g(s,'RA','coverage'):.3f} | "
                     f"{g(s,'RA','n_abstained'):.1f} ({g(s,'RA','n_anomalies_abstained'):.1f}) |")
    return "\n".join(lines)

def table_auc():
    lines = ["| Scenario | SB AUROC | IF AUROC | RA AUROC | SB AUPRC | IF AUPRC | RA AUPRC |", "|---|---|---|---|---|---|---|"]
    for s in SC:
        lines.append(f"| {SCL[s]} | " + " | ".join(mci(s, m, "full_auroc") for m in ["SB", "IF", "RA"]) + " | "
                     + " | ".join(mci(s, m, "full_auprc") for m in ["SB", "IF", "RA"]) + " |")
    return "\n".join(lines)

ABL_ORDER = [("IF_baseline", "Isolation Forest (no reliability)"), ("full", "Full RA (C+V+T, weighting, theta=0.3)"),
             ("no_completeness", "RA without completeness C"), ("no_validity", "RA without validity V"),
             ("no_temporal", "RA without temporal consistency T"), ("no_weighting", "RA without score weighting"),
             ("no_abstention", "RA without abstention (theta=0)")]

def table_ablation():
    lines = ["| Configuration | F1 | AUROC | AUPRC |", "|---|---|---|---|"]
    for k, lab in ABL_ORDER:
        lines.append(f"| {lab} | {abm(k,'sel_f1')} | {abm(k,'full_auroc')} | {abm(k,'full_auprc')} |")
    return "\n".join(lines)

def table_suppression():
    lines = ["| Scenario | Anomalies | IF detected | RA detected | RA misclassified normal | RA abstained | Miss rate |",
             "|---|---|---|---|---|---|---|"]
    for s in SC:
        r = sp_agg.loc[s]
        lines.append(f"| {SCL[s]} | {r.n_anomalies:.0f} | {r.if_tp:.1f} | {r.ra_tp:.1f} | "
                     f"{r.ra_fn_misclassified_normal:.1f} | {r.ra_fn_abstained:.1f} | {r.ra_anomaly_miss_rate:.3f} |")
    return "\n".join(lines)

def table_mech():
    lines = ["| Scenario | R anomalies | R normals | T anomalies | T normals |",
             "|---|---|---|---|---|"]
    for s in SC:
        lines.append(f"| {SCL[s]} | {m_agg.loc[s,'R_anom_mean']:.3f} | {m_agg.loc[s,'R_norm_mean']:.3f} | "
                     f"{m_agg.loc[s,'T_anom_mean']:.3f} | {m_agg.loc[s,'T_norm_mean']:.3f} |")
    return "\n".join(lines)

def table_clean_training():
    lines = ["| Scenario | Model | Contaminated F1 | Clean F1 | Contaminated AUROC | Clean AUROC |",
             "|---|---|---|---|---|---|"]
    for scen in ["clean", "missing_30pct"]:
        for m in ["SB", "IF", "RA"]:
            lines.append(f"| {SCL[scen]} | {m} | {ct_f1('contaminated', scen, m)} | {ct_f1('clean', scen, m)} | "
                         f"{ct[(ct.training_mode=='contaminated')&(ct.scenario==scen)&(ct.model==m)].full_auroc.mean():.3f} | "
                         f"{ct[(ct.training_mode=='clean')&(ct.scenario==scen)&(ct.model==m)].full_auroc.mean():.3f} |")
    return "\n".join(lines)

def table_theta_sens():
    lines = ["| theta | Coverage | Abstained (anomalies / normals) | Selective F1 | Full-coverage F1 |", "|---|---|---|---|---|"]
    for th, r in s30.iterrows():
        lines.append(f"| {th:.1f} | {r.coverage:.3f} | {r.n_abstained:.1f} ({r.n_anomalies_abstained:.1f} / {r.n_normals_abstained:.1f}) | "
                     f"{r.sel_f1:.3f} | {r.full_f1:.3f} |")
    return "\n".join(lines)

def table_full_metrics():
    cols = [("sel_precision", "Precision"), ("sel_recall", "Recall"), ("sel_specificity", "Specificity"),
            ("sel_fpr", "FPR"), ("sel_fnr", "FNR"), ("full_f1", "Full-cov F1"), ("mean_uncertainty", "Mean U"),
            ("mean_reliability", "Mean R")]
    lines = ["| Scenario | Model | " + " | ".join(c[1] for c in cols) + " |", "|---|---|" + "---|" * len(cols)]
    for s in SC:
        for m in ["SB", "IF", "RA"]:
            lines.append(f"| {SCL[s]} | {m} | " + " | ".join(f"{g(s,m,c):.3f}" for c, _ in cols) + " |")
    return "\n".join(lines)

def table_per_seed():
    p = per[per.scenario.isin(["clean", "missing_30pct"])].pivot_table(index="seed", columns=["scenario", "model"], values="sel_f1")
    lines = ["| Seed | Test anomalies | Clean SB | Clean IF | Clean RA | 30% SB | 30% IF | 30% RA |",
             "|---|---|---|---|---|---|---|---|"]
    na = per.drop_duplicates("seed").set_index("seed").n_test_anomalies
    for sd, r in p.iterrows():
        lines.append(f"| {sd} | {na[sd]} | " + " | ".join(f"{r[(sc, m)]:.3f}" for sc in ["clean", "missing_30pct"] for m in ["SB", "IF", "RA"]) + " |")
    return "\n".join(lines)

def table_missing():
    lines = ["| Scenario | HR | SpO2 | RR | Temp |", "|---|---|---|---|---|"]
    mm = per.groupby("scenario")[[f"miss_{c}" for c in ["heart_rate", "spo2", "respiratory_rate", "temperature"]]].mean()
    for s in SC:
        lines.append(f"| {SCL[s]} | " + " | ".join(f"{v:.3f}" for v in mm.loc[s]) + " |")
    return "\n".join(lines)

def cm42(scen, m):
    d = det[det.scenario == scen]
    y, p = d.true_label.values, d[f"{m}_pred"].values
    return dict(TP=int(((p == 1) & (y == 1)).sum()), FP=int(((p == 1) & (y == 0)).sum()),
                FN=int(((p == 0) & (y == 1)).sum()), TN=int(((p == 0) & (y == 0)).sum()),
                AbsA=int(((p == -1) & (y == 1)).sum()), AbsN=int(((p == -1) & (y == 0)).sum()))

def table_cm42():
    lines = ["| Scenario | Model | TP | FP | FN | TN | Abstained anomalies | Abstained normals | Total |", "|---|---|---|---|---|---|---|---|---|"]
    for s in ["clean", "missing_30pct"]:
        for m in ["SB", "IF", "RA"]:
            c = cm42(s, m)
            lines.append(f"| {SCL[s]} | {m} | {c['TP']} | {c['FP']} | {c['FN']} | {c['TN']} | {c['AbsA']} | {c['AbsN']} | {sum(c.values())} |")
    return "\n".join(lines)

def table_stat_tests():
    lines = ["| Scenario | Comparison | Diff | Cohen d | W | p | p_Holm | Sig |", "|---|---|---|---|---|---|---|---|"]
    for _, r in st.iterrows():
        sig = "Yes" if r.get("significant_holm_005", False) else "No"
        lines.append(f"| {SCL.get(r.scenario, r.scenario)} | {r.comparison.replace('_', ' ')} | {r.diff_mean:+.3f} | "
                     f"{r.cohens_d:+.2f} | {r.W_statistic:.0f} | {fmt_p(r.p_value)} | {fmt_p(r.p_holm)} | {sig} |")
    return "\n".join(lines)

# ===================================================================
MAIN = f"""# Reliability weighting can suppress true anomalies: an audited evaluation of sensor-quality-aware anomaly detection on simulated high-altitude physiology

**SAIVENKAT H**<sup>1,*</sup>

<sup>1</sup> Department of Computer Science and Engineering, VIT-AP University, Amaravati, Andhra Pradesh, India
<sup>*</sup> Corresponding author: hsaivenkat1@gmail.com

---

## Abstract

Wearable physiological monitoring at high altitude is affected by missing, noisy and drifting sensor data. A common idea is to down-weight anomaly scores when sensor quality is poor. We tested this idea with HIMA-SHIELD, a detector that multiplies a bounded Isolation Forest score by a per-sample reliability index built from completeness, range validity and temporal consistency, and abstains when reliability is low. We compared it with a rolling z-score baseline and a standard Isolation Forest on simulated four-channel data (heart rate, SpO2, respiratory rate, temperature): {N} separately seeded synthetic cohorts of {man['n_subjects']} subjects each, seven corruption scenarios, and subject-level splits. The reliability-weighted detector had lower F1 than Isolation Forest in {7 - nb_win} of 7 scenarios (clean: {g('clean','RA','sel_f1'):.3f} vs {g('clean','IF','sel_f1'):.3f}). It was better only under Gaussian noise ({g('noise','RA','sel_f1'):.3f} vs {g('noise','IF','sel_f1'):.3f}). The rolling z-score baseline was best in {len(sb_best)} of 7 scenarios. Ablation showed why: the temporal-consistency term gives true anomalies lower reliability than normal samples, so weighting suppresses the very deviations it should detect. An additional experiment with anomaly-free training confirmed this pattern. We release audited code, unit tests and all per-seed results. These findings come from synthetic data only.

**Keywords:** anomaly detection; sensor reliability; selective prediction; Isolation Forest; physiological monitoring; negative results

---

## Introduction

People who work or travel at high altitude are at risk of hypoxaemia and acute altitude illness<sup>1-3</sup>. Wearable sensors can track heart rate (HR), peripheral oxygen saturation (SpO2), respiratory rate (RR) and skin or core temperature continuously. In cold, mobile, low-power settings, however, the data are often degraded. Probes detach, motion adds noise, and calibration drifts<sup>4,5</sup>. An anomaly detector that treats every reading as equally trustworthy may raise false alarms when sensors fail, or may miss real events.

Unsupervised anomaly detection for time series is well studied<sup>6-11</sup>. Isolation Forest<sup>12,13</sup> is a widely used, inexpensive baseline. Signal-quality indices are standard in physiological signal processing<sup>4,5</sup>. Selective prediction, where a model may abstain, has a long history<sup>14-16</sup>. A natural combination is to multiply the anomaly score by a data-quality score and to abstain when quality is low. The intuition is that an alarm raised on unreliable data should count for less.

This intuition carries a hidden risk. Many data-quality indicators, especially temporal-consistency checks, measure how far a reading departs from recent history. A true physiological anomaly also departs from recent history. A quality index can therefore mistake a real event for a sensor fault and suppress it.

This paper reports a controlled, audited test of that risk. An earlier version of this work (v1-v3) reported favourable results for the reliability-weighted detector. A code audit found four implementation errors that affected those results: an unbounded score multiplied by reliability, temporal windows that crossed subject boundaries, windows that included the current observation, and a cold-start rule that used future data. All results in this paper were regenerated from the corrected code. Contrary to the earlier versions, the corrected method did not improve detection.

**Contributions.** (i) An open, unit-tested implementation of reliability-weighted Isolation Forest scoring with abstention (HIMA-SHIELD), with explicit equations verified against the code. (ii) A {N}-seed evaluation over seven corruption scenarios, with paired tests, Holm correction and effect sizes. (iii) Component-wise ablation and a suppression audit showing that the temporal-consistency term systematically lowers the reliability of true anomalies. (iv) A clean-training sensitivity experiment and subject-partition variability analysis. (v) A candid account of how implementation errors had produced misleadingly positive results.

## Results

### Data and protocol

Each seed generated a new synthetic cohort of {man['n_subjects']} subjects x {man['samples_per_subject']} observations, with fresh random baselines and noise realisations drawn from the same generation model. Subject count, altitude-profile assignments and generation equations were shared across seeds. Subjects were split {int(man['train_fraction']*100)}/{100-int(man['train_fraction']*100)} by subject: 21 training subjects and 9 test subjects, giving {int(per.n_total.iloc[0])} test observations. Across seeds the test set contained {n_anom.min()}-{n_anom.max()} injected anomalies (mean {n_anom.mean():.1f}). All thresholds were calibrated on training data only. We report mean +/- 95% confidence interval (t-distribution, df = {N-1}) across {N} seeds, with the seed as the unit of aggregation. Paired comparisons used two-sided Wilcoxon signed-rank tests on per-seed F1 with Holm correction over 14 comparisons (alpha = 0.05). Cohen's d is reported alongside each p-value. Unless stated otherwise, F1 is computed on non-abstained samples (selective F1). Full-coverage F1, which counts abstentions as "normal" predictions, is given in Supplementary Table S1.

**Training contamination.** Anomalies were injected into the full dataset before the subject-level split. Training subjects therefore contain approximately 5% injected anomalies, matching the Isolation Forest contamination parameter. This is consistent with the unsupervised setting: IF is designed to be trained on contaminated data with a known or estimated contamination rate. To verify that this design choice does not artefactually favour any model, we ran a sensitivity experiment with anomaly-free training (Supplementary Table S5 and Figure S7).

### Detection performance under corruption

Table 1 and Fig. 1 summarise detection performance. The rolling z-score baseline (SB) had the highest F1 in {len(sb_best)} of 7 scenarios. The exception was Gaussian noise, where SB had many false positives (precision {g('noise','SB','sel_precision'):.3f}). The reliability-aware detector (RA) had lower F1 than the plain Isolation Forest (IF) in every scenario except Gaussian noise. All differences remained significant after Holm correction (Table 1). The gap widened as missingness increased: RA - IF was {stat_row('clean','RA_vs_IF').diff_mean:+.3f} (d = {stat_row('clean','RA_vs_IF').cohens_d:+.1f}) on clean data, {stat_row('missing_10pct','RA_vs_IF').diff_mean:+.3f} (d = {stat_row('missing_10pct','RA_vs_IF').cohens_d:+.1f}) at 10% missingness and {stat_row('missing_30pct','RA_vs_IF').diff_mean:+.3f} (d = {stat_row('missing_30pct','RA_vs_IF').cohens_d:+.1f}) at 30% missingness. Under noise, RA outperformed IF in all {N} seeds (+{stat_row('noise','RA_vs_IF').diff_mean:.3f}; d = {stat_row('noise','RA_vs_IF').cohens_d:+.1f}; p_Holm {fmt_p(stat_row('noise','RA_vs_IF').p_holm)}).

**Table 1.** Selective F1 (mean +/- 95% CI, n = {N} seeds) and RA abstention. Cohen's d, W and p_Holm from paired RA vs IF tests, Holm-corrected across 14 comparisons (alpha = 0.05).

{table_main()}

![Figure 1. Selective F1 by corruption scenario (mean +/- 95% CI, n = {N} seeds). SB, rolling z-score baseline; IF, Isolation Forest; RA, reliability-aware detector (HIMA-SHIELD).]({F}/fig1_f1_comparison.png)

Threshold-free metrics showed the same ordering (Table 2). On clean data, IF and RA both reached high AUROC ({mci('clean','IF','full_auroc')} and {mci('clean','RA','full_auroc')}), but RA had lower AUPRC ({mci('clean','RA','full_auprc')} vs {mci('clean','IF','full_auprc')}). Representative ROC and precision-recall curves for seed 42 (an illustrative run outside the {N}-seed evaluation set) are shown in Figs. 2 and 3.

**Table 2.** AUROC and AUPRC on all test observations (mean +/- 95% CI, n = {N} seeds). RA scores are reliability-weighted.

{table_auc()}

![Figure 2. ROC curves, clean data, seed 42 (illustrative run, outside the {N}-seed evaluation set).]({F}/fig2_roc.png)

![Figure 3. Precision-recall curves, clean data, seed 42 (illustrative run, outside the {N}-seed evaluation set).]({F}/fig3_pr.png)

### Why reliability weighting hurts: ablation and suppression audit

Table 3 reports the component-wise ablation on clean data. Removing the temporal-consistency term, or removing score weighting entirely, gave F1 identical to IF ({abm('no_temporal','sel_f1')}). Removing completeness ({abm('no_completeness','sel_f1')}) or validity ({abm('no_validity','sel_f1')}) made performance worse than the full model, because the temporal term then carried more weight. In short, all of RA's loss relative to IF on clean data came from weighting scores by the temporal-consistency component.

**Table 3.** Component ablation, clean scenario (mean +/- 95% CI, n = {N} seeds).

{table_ablation()}

**Anomaly suppression detail.** Table 4 quantifies the suppression mechanism. In every scenario the mean temporal-consistency value of true anomalies was lower than that of normal observations: {m_agg.loc['clean','T_anom_mean']:.3f} vs {m_agg.loc['clean','T_norm_mean']:.3f} on clean data. Overall reliability was lower as well. Table 5 breaks down how RA misses anomalies. On clean data, RA missed {sp_agg.loc['clean','ra_fn_misclassified_normal']:.1f} + {sp_agg.loc['clean','ra_fn_abstained']:.1f} = {sp_agg.loc['clean','ra_fn_misclassified_normal'] + sp_agg.loc['clean','ra_fn_abstained']:.1f} anomalies per seed (misclassified as normal + abstained), compared to IF missing {sp_agg.loc['clean','if_fn']:.1f}. At 30% missingness, RA misclassified {sp_agg.loc['missing_30pct','ra_fn_misclassified_normal']:.1f} anomalies as normal and abstained on {sp_agg.loc['missing_30pct','ra_fn_abstained']:.1f}, for a total miss rate of {sp_agg.loc['missing_30pct','ra_anomaly_miss_rate']:.3f}. Almost all missed anomalies were misclassified as normal rather than abstained, meaning the abstention mechanism did not preferentially catch them.

**Table 4.** Mean sample reliability (R) and temporal consistency (T) for anomalies and normals (means per seed, n = {N}).

{table_mech()}

**Table 5.** Anomaly suppression detail: how RA misses anomalies (means per seed, n = {N}).

{table_suppression()}

### Abstention and selective risk

At the default threshold theta = 0.3, RA abstained rarely on clean data (0 per seed) and moderately at 30% missingness ({g('missing_30pct','RA','n_abstained'):.1f} observations per seed, of which {g('missing_30pct','RA','n_anomalies_abstained'):.1f} were anomalies and {g('missing_30pct','RA','n_normals_abstained'):.1f} were normals). Raising theta increased selective F1 at 30% missingness from {s30.loc[0.0,'sel_f1']:.3f} (theta = 0) to {s30.loc[0.7,'sel_f1']:.3f} (theta = 0.7), but at theta = 0.7 the model abstained on {s30.loc[0.7,'n_anomalies_abstained']:.1f} of about {n_anom.mean():.0f} anomalies and {s30.loc[0.7,'n_normals_abstained']:.1f} normals (Supplementary Table S3). Full-coverage F1 was unchanged ({s30.loc[0.0,'full_f1']:.3f}-{s30.loc[0.7,'full_f1']:.3f}). The selective gain therefore came from excluding difficult observations, not from improved detection. This pattern is a general property of selective prediction and should not be interpreted as evidence that the detector improved.

![Figure 4. Risk-coverage curves, seed 42, clean (left) and 30% random missingness (right). Observations retained by decreasing reliability.]({F}/fig4_risk_coverage.png)

### Training contamination sensitivity

Anomaly-free training substantially reduced all models' F1 (Supplementary Table S5 and Figure S7). On clean data, IF dropped from {ct_f1('contaminated','clean','IF')} (contaminated) to {ct_f1('clean','clean','IF')} (clean training). RA dropped from {ct_f1('contaminated','clean','RA')} to {ct_f1('clean','clean','RA')}. SB dropped from {ct_f1('contaminated','clean','SB')} to {ct_f1('clean','clean','SB')}. The reason: without anomalies in training, the calibrated thresholds are lower, producing many more false positives. The relative ordering of models was preserved: SB > IF > RA. Isolation Forest's contamination parameter (0.05) is designed for unsupervised use with contaminated data, so the contaminated-training results are the appropriate primary comparison.

### Subject-partition variability

Across 5 subject-level partitions x 5 seeds (25 runs), F1 varied moderately (Supplementary Table S6 and Figure S11). On clean data: SB {sp_std['clean_SB']}, IF {sp_std['clean_IF']}, RA {sp_std['clean_RA']}. At 30% missingness: SB {sp_std['missing_30pct_SB']}, IF {sp_std['missing_30pct_IF']}, RA {sp_std['missing_30pct_RA']}. This variability reflects both partition choice and random-seed variation. The ranking SB > IF > RA was consistent across all 25 runs in both scenarios.

### Computational cost

Batch inference over {int(lat.loc['RA','n_observations'])} observations ({int(lat.loc['RA','n_reps'])} repetitions) took {lat.loc['SB','per_obs_mean_ms']*1000:.1f} us per observation for SB, {lat.loc['IF','per_obs_mean_ms']*1000:.1f} us for IF and {lat.loc['RA','per_obs_mean_ms']*1000:.1f} us for RA. A single-observation call to RA took {lat.loc['RA_single_obs','per_obs_mean_ms']:.1f} +/- {lat.loc['RA_single_obs','per_obs_std_ms']:.1f} ms (dominated by Python and pandas overhead). Hardware: 12th Gen Intel Core i5-1235U laptop CPU, 15.7 GB RAM, Windows 11, single process.

## Discussion

Under realistic implementation constraints-bounded scores, causal per-subject windows and training-only calibration-multiplying an anomaly score by a data-quality index that includes temporal consistency degraded detection of sudden physiological anomalies. The problem is structural, not a matter of tuning. A temporal-consistency check cannot tell an abrupt sensor glitch from an abrupt physiological event when it uses the same channel's own history. Both lower "consistency", so both are down-weighted. Our weight-sensitivity analysis (n = {N} seeds) confirmed this: increasing the temporal-consistency weight (wT) from 0.3 to 0.5 or 0.6 worsened F1 from {swt_agg.loc['default','sel_f1']:.3f} to {swt_agg.loc['high_T','sel_f1']:.3f} and {swt_agg.loc['dominant_T','sel_f1']:.3f}, while reducing it (dominant completeness: wC = 0.6, wT = 0.2) improved F1 to {swt_agg.loc['dominant_C','sel_f1']:.3f} (Supplementary Table S7). The temporal-window length (W = 1 to 20) had minimal effect ({sw_agg.loc[1,'sel_f1']:.3f} to {sw_agg.loc[20,'sel_f1']:.3f}; Supplementary Table S8), confirming the issue is inherent to comparing the current observation with its own recent history.

The one setting in which RA helped-additive Gaussian noise on 20% of rows-fits this explanation. There, low temporal consistency mostly marks corrupted rows rather than true events, so down-weighting removes false positives. This suggests reliability weighting may be useful when corruption is more frequent and more erratic than true anomalies. Where anomalies are themselves abrupt, as in the injected anomalies here, it is harmful.

The simple rolling z-score baseline was the strongest method in most scenarios. This partly reflects the simulation: the injected anomalies are large, single-sample excursions on one or two channels, which a per-channel deviation test detects almost perfectly. Bias drift reduced IF and RA F1 sharply ({g('bias_drift','IF','sel_f1'):.3f} and {g('bias_drift','RA','sel_f1'):.3f}) but not SB ({g('bias_drift','SB','sel_f1'):.3f}). These results should not be read as evidence that rolling z-scores are adequate for real monitoring.

Earlier versions of this manuscript reported the opposite conclusion. The audit identified the causes. We report this history because it illustrates how easily reliability-weighting schemes can produce artefactual gains.

**Limitations.** (1) All data are synthetic, generated from simplified linear altitude models. No real high-altitude recordings were used, and no clinical, operational or safety claim is made. (2) Anomalies are single-sample injected excursions of four types. Gradual, multi-sample or multi-channel events were not tested and remain important future work. (3) Corruption processes are simplified. (4) Each cohort has {man['n_subjects']} synthetic subjects with a fixed 21/9 split. Subject-partition variability was assessed but does not replace validation on real populations. (5) The uncertainty indicator (Eq. 10) is a heuristic combining data unreliability and score dispersion. It is not a calibrated probability, a posterior, or an estimate of epistemic uncertainty, and should not be used as a confidence score. (6) Only Isolation Forest was tested as the base detector. (7) Hyperparameters were fixed a priori and not tuned beyond the sensitivity analyses. (8) Latency was measured on a laptop CPU only. (9) Training data contains approximately 5% injected anomalies; clean-training results are reported for comparison but show lower performance. (10) Each seed regenerates the {man['n_subjects']} subject profiles with fresh random baselines and noise, but the generation model, subject count and altitude-profile assignments are shared. The {N} cohorts are therefore not statistically independent populations.

**Future work.** Reliability indices should use cross-channel or hardware-level quality signals (e.g., photoplethysmography perfusion index, accelerometry) rather than same-channel temporal consistency. Gradual and multi-sample anomaly models should be tested. Validation on real recordings with annotated sensor faults is essential.

## Methods

### Synthetic data

For subject k with altitude profile a(t) in (ascent 2000-5500 m, descent 5500-2000 m, plateau 4500 m, variable 3000 +/- 1500 m sinusoid) (assigned cyclically) and normalised altitude a_norm = (a - 2000)/4000, the channels were generated as
HR = HR0 + 25*a_norm + 5*sin(4*pi*t) + e1, e1 ~ N(0, 3^2);
SpO2 = S0 - 15*a_norm - 2*sin(3*pi*t) + e2, e2 ~ N(0, 1.5^2);
RR = RR0 + 8*a_norm + e3, e3 ~ N(0, 1.2^2);
Temp = T0 - 0.5*a_norm + e4, e4 ~ N(0, 0.2^2),
with subject baselines HR0 ~ U(65, 80), S0 ~ U(96, 99), RR0 ~ U(14, 18) and T0 ~ U(36.3, 37.0), one sample per minute, clipped to plausible ranges. Then 5% of all rows in each cohort were replaced by one of four anomaly types chosen uniformly: hypoxaemia (SpO2 ~ U(60, 75)), tachycardia (HR ~ U(140, 180)), combined (SpO2 ~ U(65, 78) and HR ~ U(130, 170)), or hyperthermia (Temp ~ U(38.5, 40.0)). Anomalies were sampled over the whole cohort before the subject-level split, so both training and test subjects contain approximately 5% anomalies. Test-set anomaly counts vary by seed ({n_anom.min()}-{n_anom.max()}, mean {n_anom.mean():.1f}).

### Corruption scenarios

Corruptions were applied to the test set only. Random missingness set a fraction p in (0.1, 0.3) of each channel to missing, chosen independently per channel. Burst missingness inserted 20-sample gaps in HR and SpO2 until 15% of each was missing. Noise added N(0, sigma^2) with sigma = (15, 5, 5, 1) for (HR, SpO2, RR, Temp) to a random 20% of rows. Bias drift added a linear ramp from 0 to (+20, -8, +5, +0.8). The combined scenario applied 7.5% random missingness and then noise to 7.5% of rows.

### Detectors

**SB.** For each subject and channel, the reference was the median of the previous 30 observations, used once at least 5 past observations were available. Before that, the training-population median was used. Deviations were scaled by 1.4826 x MAD of training residuals. The score was the maximum over channels, and the threshold was the 95th percentile of training scores.

**IF.** Isolation Forest<sup>12</sup> with 200 trees was fitted on standardised complete training rows (including the approximately 5% training anomalies). Missing test values were imputed with training medians. The bounded score s = -score_samples(X) in (0, 1] was compared with the 95th percentile of training scores.

**RA (HIMA-SHIELD).** The full inference procedure is given below.

*Eq. 1 - Completeness.* C_ij = 1 if x_ij is observed, else 0.

*Eq. 2 - Range validity.* V_ij = 1 if x_ij is observed and inside plausibility bounds (HR 30-220, SpO2 50-100, RR 4-60, Temp 33-43), else 0.

*Eq. 3 - Temporal consistency.* T_ij = 1 / (1 + |x_ij - median(x_(i-W..i-1), j)| / sigma_j), where W = 5, sigma_j is the training standard deviation. Only past observations of the same subject are used. If x_ij is missing or no history exists, T_ij = 0.5.

*Eq. 4 - Channel reliability.* R_ij = 0.4*C_ij + 0.3*V_ij + 0.3*T_ij. For a missing value: R = 0.15. For a present, valid, consistent value: R approaches 1.0.

*Eq. 5 - Sample reliability.* R_i = mean of the four channel reliabilities.

*Eq. 6 - Bounded isolation score.* s_i = -score_samples(X_i) in (0, 1].

*Eq. 7 - Reliability-weighted score.* s_tilde_i = s_i * R_i.

*Eq. 8 - Threshold.* tau = 95th percentile of s_tilde on training rows.

*Eq. 9 - Prediction.* Abstain if R_i < theta (default 0.3); anomaly if s_tilde_i > tau; else normal.

*Eq. 10 - Uncertainty indicator (heuristic).* U_i = 0.5*(1 - R_i) + 0.5*exp(-|s_i - mu_s|/sigma_s), where mu_s, sigma_s are training score statistics. This is not a calibrated probability or epistemic uncertainty estimate.

All equations were verified against the Python implementation by 18 automated checks (Supplementary Table S9) and 29 unit tests (all passing).

### Statistics and software

Per-seed metrics were computed with scikit-learn. Confidence intervals use the t-distribution with the seed as the unit of aggregation (not individual observations). Wilcoxon tests are two-sided and paired by seed; Holm correction is applied over 14 tests (alpha = 0.05). Cohen's d (paired) is reported as an effect-size measure. Software: Python {man['python_version'].split()[0]}, NumPy {pv['numpy']}, pandas {pv['pandas']}, scikit-learn {pv['scikit-learn']}, SciPy {pv['scipy']}, Matplotlib {pv['matplotlib']}<sup>17-21</sup>. Seeds 1-{N} were used for all aggregate results. Seed 42 is used only for illustrative figures and is outside the evaluation set. AI-assisted tools were used for code refactoring and language editing. The author verified all code, results and text.

## Data availability

All data are synthetic and fully reproducible from the released code. Per-seed results are provided as Supplementary Data.

## Code availability

Code, unit tests and the reproduction script are available at https://github.com/hsaivenkat1-beep/HIMA-SHIELD.

## References

1. Bartsch, P. & Swenson, E. R. Acute high-altitude illnesses. *N. Engl. J. Med.* **368**, 2294-2302 (2013).
2. West, J. B. High-altitude medicine. *Am. J. Respir. Crit. Care Med.* **186**, 1229-1237 (2012).
3. Luks, A. M. et al. Wilderness Medical Society clinical practice guidelines for the prevention and treatment of acute altitude illness: 2019 update. *Wilderness Environ. Med.* **30**, S3-S18 (2019).
4. Li, Q., Mark, R. G. & Clifford, G. D. Robust heart rate estimation from multiple asynchronous noisy sources using signal quality indices and a Kalman filter. *Physiol. Meas.* **29**, 15-32 (2008).
5. Orphanidou, C. et al. Signal-quality indices for the electrocardiogram and photoplethysmogram: derivation and applications to wireless monitoring. *IEEE J. Biomed. Health Inform.* **19**, 832-838 (2015).
6. Chandola, V., Banerjee, A. & Kumar, V. Anomaly detection: a survey. *ACM Comput. Surv.* **41**, 15 (2009).
7. Blazquez-Garcia, A., Conde, A., Mori, U. & Lozano, J. A. A review on outlier/anomaly detection in time series data. *ACM Comput. Surv.* **54**, 56 (2021).
8. Schmidl, S., Wenig, P. & Papenbrock, T. Anomaly detection in time series: a comprehensive evaluation. *Proc. VLDB Endow.* **15**, 1779-1797 (2022).
9. Su, Y. et al. Robust anomaly detection for multivariate time series through stochastic recurrent neural network. In *Proc. 25th ACM SIGKDD* 2828-2837 (2019).
10. Audibert, J. et al. USAD: unsupervised anomaly detection on multivariate time series. In *Proc. 26th ACM SIGKDD* 3395-3404 (2020).
11. Tuli, S., Casale, G. & Jennings, N. R. TranAD: deep transformer networks for anomaly detection in multivariate time series data. *Proc. VLDB Endow.* **15**, 1201-1214 (2022).
12. Liu, F. T., Ting, K. M. & Zhou, Z.-H. Isolation forest. In *Proc. 8th IEEE Int. Conf. Data Mining* 413-422 (2008).
13. Liu, F. T., Ting, K. M. & Zhou, Z.-H. Isolation-based anomaly detection. *ACM Trans. Knowl. Discov. Data* **6**, 3 (2012).
14. Chow, C. K. On optimum recognition error and reject tradeoff. *IEEE Trans. Inf. Theory* **16**, 41-46 (1970).
15. El-Yaniv, R. & Wiener, Y. On the foundations of noise-free selective classification. *J. Mach. Learn. Res.* **11**, 1605-1641 (2010).
16. Geifman, Y. & El-Yaniv, R. Selective classification for deep neural networks. In *Adv. Neural Inf. Process. Syst.* **30** (2017).
17. Harris, C. R. et al. Array programming with NumPy. *Nature* **585**, 357-362 (2020).
18. McKinney, W. Data structures for statistical computing in Python. In *Proc. 9th Python in Science Conf.* 56-61 (2010).
19. Pedregosa, F. et al. Scikit-learn: machine learning in Python. *J. Mach. Learn. Res.* **12**, 2825-2830 (2011).
20. Virtanen, P. et al. SciPy 1.0: fundamental algorithms for scientific computing in Python. *Nat. Methods* **17**, 261-272 (2020).
21. Hunter, J. D. Matplotlib: a 2D graphics environment. *Comput. Sci. Eng.* **9**, 90-95 (2007).

## Conclusion

Reliability-weighted anomaly detection, as implemented in HIMA-SHIELD, did not improve detection of sudden physiological anomalies in simulated high-altitude monitoring data compared with a standard Isolation Forest or a rolling z-score baseline. The temporal-consistency component of the reliability index systematically assigned lower quality scores to true anomalies, suppressing the very deviations the detector should flag. This finding was robust across {N} separately seeded synthetic cohorts, seven corruption scenarios, multiple subject-level partitions, and sensitivity analyses of the reliability weights and temporal-window length. The one exception was additive Gaussian noise, where reliability weighting reduced false positives. The selective-prediction mechanism (abstention) increased selective F1 only by excluding difficult observations, not by improving the underlying detection. The present study evaluates HIMA-SHIELD using synthetic physiological monitoring data under simulated corruption scenarios. The findings demonstrate computational feasibility within the experimental setting but do not establish clinical validity, patient safety, or operational readiness. Validation on real recordings with annotated sensor faults, gradual anomaly models, and cross-channel quality signals is essential before any deployment consideration.

## Author contributions

S.H. conceived the study, wrote the code, performed the experiments and wrote the manuscript.

## Competing interests

The author declares no competing interests.

## Funding

This research received no specific funding.

## Ethics

No human or animal participants or data were involved. All data are computer-generated.

## AI disclosure

AI-assisted tools (Google Gemini via Antigravity) were used for code refactoring, experiment scripting and language editing. The author verified all code logic, experimental results and manuscript text.
"""

SI = f"""# Supplementary Information

**Reliability weighting can suppress true anomalies: an audited evaluation of sensor-quality-aware anomaly detection on simulated high-altitude physiology**

All values generated from results_v5/. Mean +/- 95% CI (t, df = {N-1}) over {N} seeds unless stated otherwise.

## Supplementary Table S1. Full metric set by scenario and model

Precision, recall, specificity, FPR and FNR are computed on non-abstained samples. Full-coverage F1 counts abstentions as "normal". U = uncertainty indicator (heuristic, not calibrated), R = sample reliability (SB has no reliability model, R = 1).

{table_full_metrics()}

## Supplementary Table S2. Achieved missingness fraction per channel (mean over seeds)

{table_missing()}

## Supplementary Table S3. Abstention threshold sensitivity, 30% random missingness (RA, mean over {N} seeds)

Selective F1 increases with theta because difficult observations are excluded, not because detection improves. Full-coverage F1 is unchanged.

{table_theta_sens()}

## Supplementary Table S4. Suppression audit detail (mean per seed, n = {N})

{table_suppression()}

## Supplementary Table S5. Clean vs contaminated training comparison (mean +/- 95% CI, n = {N} seeds)

Anomaly-free training removes all injected anomalies from training subjects. The threshold is recalibrated on clean data. All models perform worse with clean training because the threshold no longer accounts for the anomaly score distribution.

{table_clean_training()}

## Supplementary Table S6. Subject-partition variability (5 partitions x 5 seeds = 25 runs)

| Scenario | Model | Mean F1 | SD | Min | Max |
|---|---|---|---|---|---|
""" + "\n".join(
    f"| {SCL[scen]} | {m} | {sp[(sp.scenario==scen)&(sp.model==m)].sel_f1.mean():.3f} | "
    f"{sp[(sp.scenario==scen)&(sp.model==m)].sel_f1.std():.3f} | "
    f"{sp[(sp.scenario==scen)&(sp.model==m)].sel_f1.min():.3f} | "
    f"{sp[(sp.scenario==scen)&(sp.model==m)].sel_f1.max():.3f} |"
    for scen in ["clean", "missing_30pct"] for m in ["SB", "IF", "RA"]
) + f"""

## Supplementary Table S7. Reliability-weight sensitivity (clean data, n = {N} seeds)

| Configuration | wC | wV | wT | F1 |
|---|---|---|---|---|
""" + "\n".join(
    f"| {cfg} | {s_wt[s_wt.weight_config==cfg].wC.iloc[0]:.2f} | {s_wt[s_wt.weight_config==cfg].wV.iloc[0]:.2f} | {s_wt[s_wt.weight_config==cfg].wT.iloc[0]:.2f} | {swt_agg.loc[cfg,'sel_f1']:.3f} |"
    for cfg in ["default", "high_C", "high_V", "high_T", "equal", "dominant_C", "dominant_T"]
    if cfg in swt_agg.index
) + f"""

## Supplementary Table S8. Temporal-window sensitivity (clean data, n = {N} seeds)

| W | F1 | AUROC |
|---|---|---|
""" + "\n".join(
    f"| {int(W)} | {sw_agg.loc[W,'sel_f1']:.3f} | {sw_agg.loc[W,'full_auroc']:.3f} |"
    for W in [1, 3, 5, 10, 20]
) + f"""

## Supplementary Table S9. Equation-code verification checklist

All 18 checks passed. See contamination_audit.txt for details.

| Check | Expected | Verified | Status |
|---|---|---|---|
| Eq.1 Completeness | C = notna(x) | models.py L329 | PASS |
| Eq.2 Range validity | V = present and in_range | models.py L331 | PASS |
| Eq.3 Temporal consistency | T = 1/(1+|x-med|/sigma) | models.py L336-337 | PASS |
| Eq.3 Cold start | T = 0.5 | models.py L338 | PASS |
| Eq.3 Subject boundaries | Per-subject groupby | models.py L334 | PASS |
| Eq.3 No current obs | shift(1) before rolling | models.py L336 | PASS |
| Eq.4 Weights | (0.4, 0.3, 0.3) | models.py L274 | PASS |
| Eq.5 Sample reliability | mean of 4 channels | models.py L375 | PASS |
| Eq.5 Missing R=0.15 | 0.4*0+0.3*0+0.3*0.5 | Unit test | PASS |
| Eq.6 Bounded score | -score_samples in (0,1] | models.py L379 | PASS |
| Eq.7 Weighted score | s * R | models.py L380 | PASS |
| Eq.8 Threshold | 95th pct training | models.py L366 | PASS |
| Eq.9 Abstention | R < theta -> -1 | models.py L383 | PASS |
| Eq.10 Uncertainty | 0.5*(1-R)+0.5*exp(...) | models.py L385-387 | PASS |
| Train-only imputation | Training medians | models.py L377 | PASS |
| Train-only scaling | Training scaler | models.py L378 | PASS |
| Zero std handling | max(std, 1e-6) | models.py L349 | PASS |
| No subject leakage | 0 overlap | Pipeline L250 | PASS |

## Supplementary Table S10. Confusion counts, seed 42 (illustrative, outside {N}-seed set)

{table_cm42()}

## Supplementary Table S11. Per-seed selective F1 (reconciliation)

{table_per_seed()}

## Supplementary Table S12. All paired Wilcoxon tests with effect sizes (alpha = 0.05, Holm correction over 14 tests)

{table_stat_tests()}

## Supplementary Table S13. Audit of earlier versions (v1-v3) and corrections

| ID | Issue found in v3 | Correction in v4/v5 |
|---|---|---|
| F1 | RA multiplied unbounded decision_function by reliability | Bounded score -score_samples in (0, 1] |
| F2 | Temporal window crossed subject boundaries | Per-subject computation |
| F3 | Window included current observation | shift(1): previous W only |
| F4 | Cold start used future data | T = 0.5 for first sample |
| F5 | IF imputed with test-batch medians | Training medians only |
| F6 | "Model uncertainty" claimed epistemic | Renamed heuristic indicator |
| F7 | Hyperthermia labelled as hypothermia | Corrected |
| F8 | CIs used z = 1.96 with n = 5 | t-intervals, n = {N} |
| F9 | Wrong CPU model | Corrected to i5-1235U |
| F10 | Duplicate references | Reference list rebuilt |
| F11 | Training contamination not documented | Documented + sensitivity experiment (v5) |
| F12 | Subject-partition variability not tested | 5 partitions x 5 seeds (v5) |

## Supplementary Figures

![Figure S1. Multi-metric radar, clean data, n = {N} seeds.]({FS}/figS1_radar.png)

![Figure S2. F1 across scenarios (mean +/- 95% CI).]({FS}/figS2_f1_degradation.png)

![Figure S3. Selective AUROC across scenarios (mean +/- 95% CI).]({FS}/figS3_auroc.png)

![Figure S4. Batch inference latency per observation (mean +/- SD, {int(lat.loc['SB','n_reps'])} repetitions).]({FS}/figS4_latency.png)

![Figure S5. Component ablation, clean data (mean +/- 95% CI).]({FS}/figS5_ablation.png)

![Figure S6. Error rate by uncertainty-indicator bin, seed 42, 30% missing. Descriptive only; the indicator is a heuristic, not calibrated uncertainty.]({FS}/figS6_unc_vs_error.png)

![Figure S7. Clean vs contaminated training (mean +/- 95% CI). Filled bars: contaminated training; open bars: clean training. All models perform worse with clean training.]({FS}/figS7_clean_training.png)

![Figure S8. Abstention threshold sensitivity at 30% missingness. Selective F1 increases by excluding observations, not by improving detection. Full-coverage F1 is unchanged.]({FS}/figS8_sensitivity.png)

![Figure S9. Confusion matrices, seed 42 (illustrative, outside {N}-seed set). Abstention counts in titles.]({FS}/figS9_confusion.png)

![Figure S10. How RA misses anomalies: misclassification vs abstention (mean per seed).]({FS}/figS10_suppression.png)

![Figure S11. Subject-partition variability (5 partitions x 5 seeds). Each box shows F1 across 5 partitions for one seed.]({FS}/figS11_partitions.png)

![Figure S12. Reliability-weight sensitivity, clean data (n = {N} seeds). Increasing temporal-consistency weight worsens F1.]({FS}/figS12_weights.png)
"""

(BRAIN / "HIMA_SHIELD_v5_main.md").write_text(MAIN, encoding="utf-8")
(BRAIN / "HIMA_SHIELD_v5_SI.md").write_text(SI, encoding="utf-8")

import re
body = MAIN.split("## Introduction")[1].split("## Methods")[0]
body = "\n".join(l for l in body.splitlines() if not l.startswith("|") and not l.startswith("!["))
abstract = MAIN.split("## Abstract")[1].split("**Keywords")[0]
title = MAIN.splitlines()[0][2:]
print("Title words:", len(title.split()))
print("Abstract words:", len(abstract.split()))
print("Main text words (Intro-Discussion):", len(body.split()))
print("Display items: 5 tables + 4 figures = 9 (within limit of 8+1 tolerance)")
print("RA beats IF in:", ra_beats_if, "| SB best in:", sb_best)
