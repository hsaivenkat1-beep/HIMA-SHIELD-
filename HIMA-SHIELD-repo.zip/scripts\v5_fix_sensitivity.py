"""Rerun sensitivity experiments with 20 seeds (was 5)."""
import sys, time
import numpy as np
import pandas as pd
from pathlib import Path
from scipy import stats

ML_DIR = Path(r"C:\Users\hsaiv\.gemini\antigravity-ide\scratch\hima-shield\ml")
sys.path.insert(0, str(ML_DIR))
from data_generator import generate_dataset, inject_anomalies
from models import FEATURE_COLS, ReliabilityAwareDetector, IsolationForestDetector, StatisticalBaseline

BRAIN = Path(r"C:\Users\hsaiv\.gemini\antigravity\brain\49d21d80-3fde-47b1-b6a4-fe539ba2c4ce")
R = BRAIN / "results_v5"

N_SEEDS = 20
N_SUBJECTS = 30
SAMPLES_PER_SUBJECT = 500
ANOMALY_FRACTION = 0.05
TRAIN_FRAC = 0.7
CONTAMINATION = 0.05
N_ESTIMATORS = 200
DEFAULT_THETA = 0.3

def generate_split(seed):
    df = generate_dataset(n_subjects=N_SUBJECTS, samples_per_subject=SAMPLES_PER_SUBJECT, base_seed=seed)
    df, labels = inject_anomalies(df, anomaly_fraction=ANOMALY_FRACTION, seed=seed + 100)
    subjects = np.array(sorted(df["subject_id"].astype(str).unique()), dtype=object)
    rng = np.random.default_rng(seed)
    rng.shuffle(subjects)
    split = int(len(subjects) * TRAIN_FRAC)
    train_subs = [str(s) for s in subjects[:split]]
    test_subs = [str(s) for s in subjects[split:]]
    train_df = df[df["subject_id"].isin(train_subs)].copy()
    test_df = df[df["subject_id"].isin(test_subs)].copy()
    test_labels = labels[df["subject_id"].isin(test_subs)].values.astype(int)
    return train_df, test_df, test_labels

from sklearn.metrics import f1_score, roc_auc_score, average_precision_score

def metrics(out, y):
    mask = out.predictions != -1
    r = {}
    if mask.sum() > 0 and len(np.unique(y[mask])) >= 2:
        r["sel_f1"] = float(f1_score(y[mask], out.predictions[mask], zero_division=0))
    else:
        r["sel_f1"] = np.nan
    pf = out.predictions.copy(); pf[pf==-1] = 0
    if len(np.unique(y)) >= 2:
        try: r["full_auroc"] = float(roc_auc_score(y, out.scores))
        except: r["full_auroc"] = np.nan
        try: r["full_auprc"] = float(average_precision_score(y, out.scores))
        except: r["full_auprc"] = np.nan
    return r

seeds = list(range(1, N_SEEDS + 1))

# Window sensitivity - 20 seeds
print("Window sensitivity (20 seeds)...")
rows_w = []
for seed in seeds:
    print(f"  Seed {seed}", end=" ", flush=True)
    train_df, test_df, test_labels = generate_split(seed)
    for W in [1, 3, 5, 10, 20]:
        ra = ReliabilityAwareDetector(contamination=CONTAMINATION, abstention_threshold=DEFAULT_THETA,
                                      n_estimators=N_ESTIMATORS, random_state=seed, temporal_window=W)
        ra.fit(train_df, "subject_id")
        out = ra.predict(test_df, "subject_id")
        m = metrics(out, test_labels)
        m["seed"] = seed
        m["temporal_window"] = W
        rows_w.append(m)
    print("done")
pd.DataFrame(rows_w).to_csv(R / "sensitivity_window.csv", index=False)
print(f"  -> sensitivity_window.csv ({len(rows_w)} rows)")

# Weight sensitivity - 20 seeds
print("Weight sensitivity (20 seeds)...")
weight_configs = [
    (0.4, 0.3, 0.3, "default"),
    (0.5, 0.25, 0.25, "high_C"),
    (0.25, 0.5, 0.25, "high_V"),
    (0.25, 0.25, 0.5, "high_T"),
    (0.33, 0.33, 0.34, "equal"),
    (0.6, 0.2, 0.2, "dominant_C"),
    (0.2, 0.2, 0.6, "dominant_T"),
]
rows_wt = []
for seed in seeds:
    print(f"  Seed {seed}", end=" ", flush=True)
    train_df, test_df, test_labels = generate_split(seed)
    for wC, wV, wT, label in weight_configs:
        ra = ReliabilityAwareDetector(contamination=CONTAMINATION, abstention_threshold=DEFAULT_THETA,
                                      n_estimators=N_ESTIMATORS, random_state=seed, weights=(wC, wV, wT))
        ra.fit(train_df, "subject_id")
        out = ra.predict(test_df, "subject_id")
        m = metrics(out, test_labels)
        m["seed"] = seed
        m["weight_config"] = label
        m["wC"] = wC; m["wV"] = wV; m["wT"] = wT
        rows_wt.append(m)
    print("done")
pd.DataFrame(rows_wt).to_csv(R / "sensitivity_weights.csv", index=False)
print(f"  -> sensitivity_weights.csv ({len(rows_wt)} rows)")
print("DONE")
