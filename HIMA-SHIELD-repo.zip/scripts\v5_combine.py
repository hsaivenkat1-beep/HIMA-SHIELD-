"""Build v5 PDFs: combined, main-only, and SI-only -> Downloads."""
import re, os, shutil, markdown
from fpdf import FPDF

BRAIN = r"C:\Users\hsaiv\.gemini\antigravity\brain\49d21d80-3fde-47b1-b6a4-fe539ba2c4ce"
DL = r"C:\Users\hsaiv\Downloads"
REPL = {'\u2082': '2', '\u03c1': 'rho', '\u03c3': 'sigma', '\u03b8': 'theta', '\u03bc': 'mu',
        '\u2192': '->', '\u2212': '-', '\u00d7': 'x', '\u2264': '<=', '\u2265': '>=', '\u00b1': '+/-',
        '\u2013': '-', '\u2014': '--', '\u2018': "'", '\u2019': "'", '\u201c': '"', '\u201d': '"',
        '\u2248': '~', '\u2022': '*', '\u2026': '...', '\u00a0': ' ', '\u00b0': ' deg', '\u00b5': 'u',
        '\u2208': ' in ', '\u03a3': 'Sum', '\u0303': '~', '\u0304': '', '\u2080': '0', '\u2081': '1',
        '\u2083': '3', '\u2084': '4', '\u2090': 'a', '\u1d62': 'i', '\u2c7c': 'j',
        'R\u0304': 'R_mean', 'T\u0304': 'T_mean', 's\u0303': 's~', 'a\u0303': 'a~'}

class PDF(FPDF):
    title_txt = ""
    def header(self):
        if self.page_no() > 1 and self.title_txt:
            self.set_font('Helvetica', 'I', 8); self.set_text_color(140, 140, 140)
            self.cell(0, 5, self.title_txt, align='C'); self.ln(8); self.set_text_color(0, 0, 0)
    def footer(self):
        self.set_y(-15); self.set_font('Helvetica', 'I', 8); self.set_text_color(140, 140, 140)
        self.cell(0, 10, f'Page {self.page_no()}/{{nb}}', align='C')

def build(md_name, img_w):
    md = open(os.path.join(BRAIN, md_name), encoding="utf-8").read()
    for k in sorted(REPL, key=len, reverse=True): md = md.replace(k, REPL[k])
    md = md.encode("latin-1", errors="replace").decode("latin-1")
    html = markdown.markdown(md, extensions=["tables"], output_format="html5")
    def fix_img(m):
        alt, s = m.group(1), m.group(2).replace("/", "\\")
        return f'<center><img src="{s}" width="{img_w}"></center><font size="8"><i>{alt}</i></font><br>'
    html = re.sub(r'<img\s+alt="([^"]*?)"\s+src="([^"]*?)"\s*/?>', fix_img, html)
    html = re.sub(r"<hr\s*/?>", "<br>", html)
    html = re.sub(r"<code>(.*?)</code>", r'<font face="Courier">\1</font>', html)
    html = re.sub(r"<sup>(.*?)</sup>", r"[\1]", html)
    html = html.replace("<table>", '<table border="1" cellpadding="1">')
    html = re.sub(r"<table[^>]*>.*?</table>", lambda m: re.sub(r"</?(font|em|strong|i|b|code)[^>]*>", "", m.group(0)), html, flags=re.S)
    return html

PAPER_TITLE = "HIMA-SHIELD: Reliability-Weighted Anomaly Detection for High-Altitude Physiological Monitoring"

def make_pdf(parts, title_txt, out_name, img_w_main=460, img_w_si=370, font_sz=10):
    """parts: list of (md_filename, img_width)"""
    pdf = PDF("P", "mm", "A4")
    pdf.title_txt = title_txt
    pdf.alias_nb_pages()
    pdf.set_auto_page_break(True, 16)
    pdf.set_margins(16, 15, 16)
    for i, (md, iw) in enumerate(parts):
        pdf.add_page()
        pdf.set_font("Helvetica", size=font_sz)
        pdf.write_html(build(md, iw), table_line_separators=True)
    out = os.path.join(BRAIN, out_name)
    pdf.output(out)
    shutil.copy2(out, os.path.join(DL, out_name))
    pages = pdf.page_no()
    sz = os.path.getsize(out) / 1e6
    print(f"  {out_name}: {pages} pages, {sz:.2f} MB -> Downloads")
    return pages

print("Building PDFs...")

# 1) Combined manuscript + SI
p1 = make_pdf(
    [("HIMA_SHIELD_v5_main.md", 460), ("HIMA_SHIELD_v5_SI.md", 370)],
    PAPER_TITLE,
    "HIMA_SHIELD_v5_Complete.pdf"
)

# 2) Main manuscript only
p2 = make_pdf(
    [("HIMA_SHIELD_v5_main.md", 460)],
    PAPER_TITLE,
    "HIMA_SHIELD_v5_Manuscript.pdf"
)

# 3) Supplementary Information only
p3 = make_pdf(
    [("HIMA_SHIELD_v5_SI.md", 370)],
    "HIMA-SHIELD Supplementary Information",
    "HIMA_SHIELD_v5_Supplementary.pdf"
)

print(f"\nDONE: Combined={p1}pp, Main={p2}pp, SI={p3}pp")
