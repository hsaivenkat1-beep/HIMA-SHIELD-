"""
HIMA-SHIELD v4 Mathematical Audit Tests.

Every test here corresponds to a specific checklist item from the v4
scientific audit. Tests are grouped by concern:

  Group A: Bounded values (T, R, U, scores all in expected ranges)
  Group B: Missing-value handling (C=0, V=0, T=0.5, R=0.15)
  Group C: Sample reliability = mean of 4 channel reliabilities
  Group D: Abstention fires iff R < theta
  Group E: No test-data leakage (threshold unchanged when test data altered)
  Group F: Causality (temporal at index i unchanged by future/other subjects)
  Group G: Edge cases (sigma=0, all-NaN channel, single-row subject)
  Group H: Bounded isolation score in (0, 1]
  Group I: Per-subject temporal isolation
  Group J: Ablation switches

Run:
    python -m pytest tests/test_math_audit.py -v
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Ensure models module is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models import (
    FEATURE_COLS,
    VALIDITY_RANGES,
    ReliabilityAwareDetector,
    IsolationForestDetector,
    StatisticalBaseline,
)
from data_generator import generate_dataset, inject_anomalies


# -----------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------
def _make_clean_dataset(n_subjects=10, samples=500, seed=42):
    """Generate and inject anomalies; return (df, labels, train, test, test_labels)."""
    df = generate_dataset(n_subjects=n_subjects, samples_per_subject=samples, base_seed=seed)
    df, labels = inject_anomalies(df, anomaly_fraction=0.05, seed=seed + 100)
    subjects = sorted(df["subject_id"].unique())
    rng = np.random.default_rng(seed)
    rng.shuffle(subjects)
    split = int(len(subjects) * 0.7)
    train_subs = list(subjects[:split])
    test_subs = list(subjects[split:])
    train_mask = df["subject_id"].isin(train_subs)
    test_mask = df["subject_id"].isin(test_subs)
    return df, labels, df[train_mask].copy(), df[test_mask].copy(), labels[test_mask].values.astype(int)


def _fit_ra(train_df, **kwargs):
    ra = ReliabilityAwareDetector(contamination=0.05, n_estimators=100,
                                   random_state=42, **kwargs)
    ra.fit(train_df, subject_col="subject_id")
    return ra


@pytest.fixture(scope="module")
def dataset():
    return _make_clean_dataset()


@pytest.fixture(scope="module")
def ra_model(dataset):
    _, _, train, _, _ = dataset
    return _fit_ra(train)


# -----------------------------------------------------------------------
# Group A: Bounded values
# -----------------------------------------------------------------------
class TestBoundedValues:
    """Every T, R, U value is finite and in [0, 1]."""

    def test_reliability_bounded(self, ra_model, dataset):
        _, _, _, test, _ = dataset
        rel = ra_model.compute_reliability(test, "subject_id")
        assert rel.notna().all().all(), "Reliability contains NaN"
        assert (rel >= 0).all().all(), "Reliability < 0"
        assert (rel <= 1).all().all(), "Reliability > 1"

    def test_uncertainty_bounded(self, ra_model, dataset):
        _, _, _, test, _ = dataset
        out = ra_model.predict(test, "subject_id")
        assert np.all(np.isfinite(out.uncertainties)), "Uncertainty not finite"
        assert np.all(out.uncertainties >= 0), "Uncertainty < 0"
        assert np.all(out.uncertainties <= 1), "Uncertainty > 1"

    def test_scores_bounded(self, ra_model, dataset):
        _, _, _, test, _ = dataset
        out = ra_model.predict(test, "subject_id")
        assert np.all(np.isfinite(out.scores)), "Scores not finite"
        # Weighted scores s*R can be < raw score, but must be >= 0
        assert np.all(out.scores >= 0), "Weighted score < 0"

    def test_reliability_scores_bounded(self, ra_model, dataset):
        _, _, _, test, _ = dataset
        out = ra_model.predict(test, "subject_id")
        assert np.all(out.reliability_scores >= 0), "reliability_scores < 0"
        assert np.all(out.reliability_scores <= 1), "reliability_scores > 1"


# -----------------------------------------------------------------------
# Group B: Missing-value handling
# -----------------------------------------------------------------------
class TestMissingValueHandling:
    """Missing -> C=0, V=0, T=0.5 -> channel R = 0.4*0 + 0.3*0 + 0.3*0.5 = 0.15."""

    def test_all_channels_missing_gives_R015(self, ra_model):
        """A row with all 4 channels NaN should have channel R = 0.15 each."""
        row = pd.DataFrame({
            "subject_id": ["SYNTH-999"],
            "heart_rate": [np.nan],
            "spo2": [np.nan],
            "respiratory_rate": [np.nan],
            "temperature": [np.nan],
        })
        rel = ra_model.compute_reliability(row, "subject_id")
        for col in FEATURE_COLS:
            r = rel[col].iloc[0]
            assert abs(r - 0.15) < 1e-6, f"Channel {col} R={r}, expected 0.15"

    def test_single_channel_missing(self, ra_model):
        """One channel NaN, others present and valid -> that channel R=0.15."""
        row = pd.DataFrame({
            "subject_id": ["SYNTH-001"],
            "heart_rate": [75.0],
            "spo2": [np.nan],
            "respiratory_rate": [16.0],
            "temperature": [36.5],
        })
        rel = ra_model.compute_reliability(row, "subject_id")
        assert abs(rel["spo2"].iloc[0] - 0.15) < 1e-6, "Missing SpO2 should give R=0.15"
        # Present channels should have R > 0.15
        for col in ["heart_rate", "respiratory_rate", "temperature"]:
            assert rel[col].iloc[0] > 0.15, f"Present {col} should have R > 0.15"

    def test_completeness_zero_for_missing(self, ra_model):
        """C_ij = 0 when value is NaN."""
        row = pd.DataFrame({
            "subject_id": ["SYNTH-001"],
            "heart_rate": [np.nan], "spo2": [95.0],
            "respiratory_rate": [16.0], "temperature": [36.5],
        })
        rel = ra_model.compute_reliability(row, "subject_id")
        # With default weights (0.4, 0.3, 0.3):
        # Missing HR: C=0, V=0, T=0.5 -> R = 0.3*0.5 = 0.15
        assert abs(rel["heart_rate"].iloc[0] - 0.15) < 1e-6


# -----------------------------------------------------------------------
# Group C: Sample reliability = mean of 4 channels
# -----------------------------------------------------------------------
class TestSampleReliability:
    """R_sample = mean(R_HR, R_SpO2, R_RR, R_Temp)."""

    def test_sample_r_is_channel_mean(self, ra_model, dataset):
        _, _, _, test, _ = dataset
        rel = ra_model.compute_reliability(test, "subject_id")
        channel_mean = rel[FEATURE_COLS].mean(axis=1).values
        out = ra_model.predict(test, "subject_id")
        np.testing.assert_allclose(out.reliability_scores, channel_mean, atol=1e-10,
                                   err_msg="Sample reliability != mean of channel reliabilities")


# -----------------------------------------------------------------------
# Group D: Abstention fires iff R < theta
# -----------------------------------------------------------------------
class TestAbstention:
    """predictions == -1 iff reliability_scores < theta."""

    def test_abstention_threshold(self, dataset):
        _, _, train, test, _ = dataset
        theta = 0.3
        ra = _fit_ra(train, abstention_threshold=theta)
        out = ra.predict(test, "subject_id")
        abstained = out.predictions == -1
        below_theta = out.reliability_scores < theta
        np.testing.assert_array_equal(
            abstained, below_theta,
            err_msg="Abstention should fire iff reliability < theta"
        )

    def test_no_abstention_when_theta_zero(self, dataset):
        _, _, train, test, _ = dataset
        ra = _fit_ra(train, abstention_threshold=0.0)
        out = ra.predict(test, "subject_id")
        assert np.all(out.predictions != -1), "theta=0 should never abstain"


# -----------------------------------------------------------------------
# Group E: No test-data leakage
# -----------------------------------------------------------------------
class TestNoLeakage:
    """Threshold unchanged when test data is altered."""

    def test_threshold_independent_of_test_data(self, dataset):
        _, _, train, test, _ = dataset
        ra1 = _fit_ra(train)
        ra2 = _fit_ra(train)
        # Alter test data
        test2 = test.copy()
        test2["heart_rate"] = 999.0
        out1 = ra1.predict(test, "subject_id")
        out2 = ra2.predict(test2, "subject_id")
        assert ra1.threshold_ == ra2.threshold_, "Threshold must be identical"
        assert ra1.score_mean_ == ra2.score_mean_, "Score mean must be identical"
        assert ra1.score_std_ == ra2.score_std_, "Score std must be identical"


# -----------------------------------------------------------------------
# Group F: Causality (temporal uses past only, per subject)
# -----------------------------------------------------------------------
class TestCausality:
    """Temporal at index i unchanged when future rows or other subjects altered."""

    def test_temporal_past_only(self, dataset):
        """Changing future test rows must not change temporal at earlier indices."""
        _, _, train, test, _ = dataset
        ra = _fit_ra(train)
        rel1 = ra.compute_reliability(test.copy(), "subject_id")

        # Corrupt the last 100 rows of the test set
        test2 = test.copy()
        test2.iloc[-100:, test2.columns.get_loc("heart_rate")] = 999.0
        rel2 = ra.compute_reliability(test2, "subject_id")

        # All rows before the corrupted region should be identical
        n_safe = len(test) - 100
        for col in FEATURE_COLS:
            np.testing.assert_array_equal(
                rel1[col].iloc[:n_safe].values,
                rel2[col].iloc[:n_safe].values,
                err_msg=f"Future corruption changed past reliability for {col}"
            )

    def test_temporal_per_subject_isolation(self, dataset):
        """Changing subject A must not affect subject B's reliability."""
        _, _, train, test, _ = dataset
        ra = _fit_ra(train)
        subjects = sorted(test["subject_id"].unique())
        if len(subjects) < 2:
            pytest.skip("Need >= 2 test subjects")
        sub_a, sub_b = subjects[0], subjects[1]

        rel1 = ra.compute_reliability(test.copy(), "subject_id")

        test2 = test.copy()
        mask_a = test2["subject_id"] == sub_a
        test2.loc[mask_a, "heart_rate"] = 999.0
        rel2 = ra.compute_reliability(test2, "subject_id")

        mask_b = test["subject_id"] == sub_b
        for col in FEATURE_COLS:
            np.testing.assert_array_equal(
                rel1[col][mask_b].values,
                rel2[col][mask_b].values,
                err_msg=f"Subject {sub_a} change affected {sub_b}'s {col} reliability"
            )


# -----------------------------------------------------------------------
# Group G: Edge cases
# -----------------------------------------------------------------------
class TestEdgeCases:
    """sigma=0, all-NaN channel, single-row subject."""

    def test_zero_std_feature(self):
        """If training feature has zero std, model should still work (EPS floor)."""
        train = pd.DataFrame({
            "subject_id": ["S1"] * 50,
            "heart_rate": [75.0] * 50,  # constant -> std=0
            "spo2": np.random.default_rng(1).uniform(90, 100, 50),
            "respiratory_rate": np.random.default_rng(2).uniform(12, 20, 50),
            "temperature": np.random.default_rng(3).uniform(36, 37.5, 50),
        })
        ra = ReliabilityAwareDetector(n_estimators=50, random_state=42)
        ra.fit(train, "subject_id")
        out = ra.predict(train, "subject_id")
        assert np.all(np.isfinite(out.scores)), "Scores not finite with zero-std feature"
        assert np.all(np.isfinite(out.uncertainties)), "Uncertainties not finite"

    def test_all_nan_channel(self):
        """Test data with one entirely NaN channel."""
        train = pd.DataFrame({
            "subject_id": ["S1"] * 50,
            "heart_rate": np.random.default_rng(1).uniform(60, 100, 50),
            "spo2": np.random.default_rng(2).uniform(90, 100, 50),
            "respiratory_rate": np.random.default_rng(3).uniform(12, 20, 50),
            "temperature": np.random.default_rng(4).uniform(36, 37.5, 50),
        })
        ra = ReliabilityAwareDetector(n_estimators=50, random_state=42)
        ra.fit(train, "subject_id")

        test = train.copy()
        test["spo2"] = np.nan  # entire channel missing
        out = ra.predict(test, "subject_id")
        assert np.all(np.isfinite(out.scores)), "Scores not finite with all-NaN channel"
        # SpO2 channel reliability should be 0.15 for all rows
        rel = ra.compute_reliability(test, "subject_id")
        np.testing.assert_allclose(rel["spo2"].values, 0.15, atol=1e-6)

    def test_single_row_subject(self):
        """A subject with a single row should get T=0.5 (no history)."""
        train = pd.DataFrame({
            "subject_id": ["S1"] * 50,
            "heart_rate": np.random.default_rng(1).uniform(60, 100, 50),
            "spo2": np.random.default_rng(2).uniform(90, 100, 50),
            "respiratory_rate": np.random.default_rng(3).uniform(12, 20, 50),
            "temperature": np.random.default_rng(4).uniform(36, 37.5, 50),
        })
        ra = ReliabilityAwareDetector(n_estimators=50, random_state=42)
        ra.fit(train, "subject_id")

        # Single-row test subject
        test = pd.DataFrame({
            "subject_id": ["S_NEW"],
            "heart_rate": [75.0],
            "spo2": [95.0],
            "respiratory_rate": [16.0],
            "temperature": [36.5],
        })
        rel = ra.compute_reliability(test, "subject_id")
        # With shift(1), first row has no reference -> T=missing_temporal_value=0.5
        # C=1, V=1, T=0.5 -> R = 0.4*1 + 0.3*1 + 0.3*0.5 = 0.85
        for col in FEATURE_COLS:
            r = rel[col].iloc[0]
            assert abs(r - 0.85) < 1e-6, f"Single-row {col} R={r}, expected 0.85"


# -----------------------------------------------------------------------
# Group H: Bounded isolation score
# -----------------------------------------------------------------------
class TestBoundedIsolationScore:
    """s = -score_samples(X) should be in (0, 1] for the standard IF."""

    def test_raw_scores_bounded(self, dataset):
        _, _, train, test, _ = dataset
        ra = _fit_ra(train)
        feats = test[FEATURE_COLS].fillna(
            {c: ra._training_stats[c]["median"] for c in FEATURE_COLS})
        X = ra.scaler.transform(feats)
        s_raw = -ra.base_model.score_samples(X)
        # Liu et al. 2008: anomaly score is in (0, 1] for normalized data
        assert np.all(s_raw > 0), f"Min raw score {s_raw.min()} <= 0"
        # In practice scores are < ~1.2; theoretical max is 1
        assert np.all(s_raw < 2.0), f"Max raw score {s_raw.max()} >= 2 (unexpected)"

    def test_if_detector_scores_positive(self, dataset):
        _, _, train, test, _ = dataset
        ifd = IsolationForestDetector(contamination=0.05, n_estimators=100, random_state=42)
        ifd.fit(train)
        out = ifd.predict(test)
        assert np.all(out.scores > 0), "IF scores should be > 0"


# -----------------------------------------------------------------------
# Group I: Per-subject temporal isolation (detailed)
# -----------------------------------------------------------------------
class TestPerSubjectTemporal:
    """Temporal consistency computed within subject only."""

    def test_first_row_of_each_subject_gets_neutral_T(self, dataset):
        """First row of every subject should have T=0.5 (no history)."""
        _, _, train, test, _ = dataset
        ra = _fit_ra(train)
        rel = ra.compute_reliability(test, "subject_id")
        for sub in test["subject_id"].unique():
            mask = test["subject_id"] == sub
            first_idx = test[mask].index[0]
            for col in FEATURE_COLS:
                r = rel.loc[first_idx, col]
                # First row: C=1, V=1 (assuming valid), T=0.5
                # R = 0.4 + 0.3 + 0.3*0.5 = 0.85
                # But if value is out of range, V could be 0 -> R=0.55
                # We check that T contributes 0.5 by checking the reliability value
                # For a valid, present value: R should be exactly 0.85
                val = test.loc[first_idx, col]
                lo, hi = VALIDITY_RANGES[col]
                if pd.notna(val) and lo <= val <= hi:
                    assert abs(r - 0.85) < 1e-6, (
                        f"Subject {sub}, channel {col}, first row R={r}, expected 0.85"
                    )


# -----------------------------------------------------------------------
# Group J: Ablation switches
# -----------------------------------------------------------------------
class TestAblationSwitches:
    """Ablation flags produce different (but valid) results."""

    def test_no_completeness(self, dataset):
        _, _, train, test, _ = dataset
        ra_full = _fit_ra(train)
        ra_no_c = _fit_ra(train, use_completeness=False)
        out_full = ra_full.predict(test, "subject_id")
        out_no_c = ra_no_c.predict(test, "subject_id")
        # Scores should differ
        assert not np.allclose(out_full.scores, out_no_c.scores), (
            "Disabling completeness should change scores"
        )
        # But still bounded
        assert np.all(np.isfinite(out_no_c.scores))
        assert np.all(out_no_c.uncertainties >= 0)
        assert np.all(out_no_c.uncertainties <= 1)

    def test_no_validity(self, dataset):
        _, _, train, test, _ = dataset
        ra_no_v = _fit_ra(train, use_validity=False)
        out = ra_no_v.predict(test, "subject_id")
        assert np.all(np.isfinite(out.scores))

    def test_no_temporal(self, dataset):
        _, _, train, test, _ = dataset
        ra_no_t = _fit_ra(train, use_temporal=False)
        out = ra_no_t.predict(test, "subject_id")
        assert np.all(np.isfinite(out.scores))

    def test_no_weighting(self, dataset):
        _, _, train, test, _ = dataset
        ra_no_w = _fit_ra(train, use_weighting=False)
        out = ra_no_w.predict(test, "subject_id")
        # Without weighting, score = s_raw, not s_raw * R
        assert np.all(np.isfinite(out.scores))

    def test_weight_renormalization(self):
        """Disabling one component should renormalize remaining weights."""
        ra = ReliabilityAwareDetector(weights=(0.4, 0.3, 0.3), use_validity=False)
        w = ra._effective_weights()
        # With validity disabled: [0.4, 0, 0.3] -> normalized [0.4/0.7, 0, 0.3/0.7]
        expected = np.array([0.4 / 0.7, 0.0, 0.3 / 0.7])
        np.testing.assert_allclose(w, expected, atol=1e-10)


# -----------------------------------------------------------------------
# Group K: Statistical Baseline correctness
# -----------------------------------------------------------------------
class TestStatisticalBaseline:
    """SB uses past-only rolling median and training-population cold start."""

    def test_sb_predictions_binary(self, dataset):
        _, _, train, test, _ = dataset
        sb = StatisticalBaseline(window_size=30, contamination=0.05)
        sb.fit(train, "subject_id")
        out = sb.predict(test, "subject_id")
        assert set(np.unique(out.predictions)).issubset({0, 1}), (
            "SB should not abstain"
        )

    def test_sb_threshold_from_training(self, dataset):
        _, _, train, test, _ = dataset
        sb = StatisticalBaseline(window_size=30, contamination=0.05)
        sb.fit(train, "subject_id")
        threshold1 = sb.z_threshold

        # Fit again on same data -> same threshold
        sb2 = StatisticalBaseline(window_size=30, contamination=0.05)
        sb2.fit(train, "subject_id")
        assert sb2.z_threshold == threshold1, "SB threshold not deterministic"

    def test_sb_pop_median_from_training(self, dataset):
        _, _, train, _, _ = dataset
        sb = StatisticalBaseline(window_size=30, contamination=0.05)
        sb.fit(train, "subject_id")
        for col in FEATURE_COLS:
            expected = float(train[col].median())
            assert abs(sb.pop_median[col] - expected) < 1e-6, (
                f"SB pop_median[{col}] should be training median"
            )


# -----------------------------------------------------------------------
# Group L: IsolationForest uses training medians
# -----------------------------------------------------------------------
class TestIFTrainingMedians:
    """IF imputes with training medians, not test-batch medians."""

    def test_if_train_median_stored(self, dataset):
        _, _, train, _, _ = dataset
        ifd = IsolationForestDetector(contamination=0.05, n_estimators=50, random_state=42)
        ifd.fit(train)
        for col in FEATURE_COLS:
            clean = train[col].dropna()
            expected = float(clean.median())
            assert abs(ifd.train_median[col] - expected) < 1e-6

    def test_if_imputation_uses_train_median(self, dataset):
        """Verify that prediction with missing values uses training median."""
        _, _, train, test, _ = dataset
        ifd = IsolationForestDetector(contamination=0.05, n_estimators=50, random_state=42)
        ifd.fit(train)

        # Create test with known missing values
        test2 = test.copy()
        test2.iloc[0, test2.columns.get_loc("heart_rate")] = np.nan
        out1 = ifd.predict(test2)

        # Manually impute and compare
        test3 = test.copy()
        test3.iloc[0, test3.columns.get_loc("heart_rate")] = ifd.train_median["heart_rate"]
        out2 = ifd.predict(test3)

        # First row scores should match (same effective input)
        assert abs(out1.scores[0] - out2.scores[0]) < 1e-10, (
            "IF should impute missing with training median"
        )


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
