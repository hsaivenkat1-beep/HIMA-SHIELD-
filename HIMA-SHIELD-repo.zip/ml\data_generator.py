"""
Synthetic data generator for HIMA-SHIELD.

Generates physiologically plausible high-altitude monitoring data for
demonstrating the pipeline. All generated data is clearly marked as SYNTHETIC.

Physiological ranges are based on published literature:
- SpO2 at sea level: 95-100%, at high altitude (>4000m): 75-92%
- Heart rate: 60-100 bpm resting, increases with altitude
- Respiratory rate: 12-20 breaths/min, increases with altitude
- Temperature: 36.1-37.2°C, may decrease at altitude

These are approximate ranges for demonstration. This is NOT clinical data.
"""
from __future__ import annotations

import json
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional

import numpy as np
import pandas as pd


def generate_subject_data(
    subject_id: str,
    n_samples: int = 500,
    altitude_profile: str = "ascent",
    seed: Optional[int] = None,
) -> pd.DataFrame:
    """Generate synthetic physiological time-series for one subject.

    Args:
        subject_id: Unique subject identifier.
        n_samples: Number of time points.
        altitude_profile: One of 'ascent', 'descent', 'plateau', 'variable'.
        seed: Random seed for reproducibility.

    Returns:
        DataFrame with timestamp, subject_id, altitude, heart_rate, spo2,
        respiratory_rate, temperature, and metadata columns.
    """
    rng = np.random.default_rng(seed)

    # Time axis: one reading every 60 seconds
    start_time = datetime(2024, 1, 1, 8, 0, 0)
    timestamps = [start_time + timedelta(seconds=60 * i) for i in range(n_samples)]

    # Altitude profile (meters)
    t = np.linspace(0, 1, n_samples)
    if altitude_profile == "ascent":
        altitude = 2000 + 3500 * t + rng.normal(0, 50, n_samples)
    elif altitude_profile == "descent":
        altitude = 5500 - 3500 * t + rng.normal(0, 50, n_samples)
    elif altitude_profile == "plateau":
        altitude = 4500 + rng.normal(0, 100, n_samples)
    elif altitude_profile == "variable":
        altitude = 3000 + 1500 * np.sin(2 * np.pi * t * 3) + rng.normal(0, 100, n_samples)
    else:
        altitude = 3000 * np.ones(n_samples)

    altitude = np.clip(altitude, 0, 8848)

    # Subject-specific baseline variation
    hr_base = rng.uniform(65, 80)
    spo2_base = rng.uniform(96, 99)
    rr_base = rng.uniform(14, 18)
    temp_base = rng.uniform(36.3, 37.0)

    # Altitude effect: higher altitude → lower SpO2, higher HR and RR
    altitude_norm = (altitude - 2000) / 4000  # normalized 0-1 over typical range

    heart_rate = (
        hr_base
        + 25 * altitude_norm  # altitude effect
        + 5 * np.sin(2 * np.pi * t * 2)  # circadian-like variation
        + rng.normal(0, 3, n_samples)  # noise
    )

    spo2 = (
        spo2_base
        - 15 * altitude_norm  # altitude effect
        - 2 * np.sin(2 * np.pi * t * 1.5)  # variation
        + rng.normal(0, 1.5, n_samples)  # noise
    )

    respiratory_rate = (
        rr_base
        + 8 * altitude_norm
        + rng.normal(0, 1.2, n_samples)
    )

    temperature = (
        temp_base
        - 0.5 * altitude_norm
        + rng.normal(0, 0.2, n_samples)
    )

    # Clip to physiological ranges
    heart_rate = np.clip(heart_rate, 40, 200)
    spo2 = np.clip(spo2, 50, 100)
    respiratory_rate = np.clip(respiratory_rate, 6, 50)
    temperature = np.clip(temperature, 34, 42)

    df = pd.DataFrame({
        "timestamp": timestamps,
        "subject_id": subject_id,
        "altitude": np.round(altitude, 1),
        "heart_rate": np.round(heart_rate, 1),
        "spo2": np.round(spo2, 1),
        "respiratory_rate": np.round(respiratory_rate, 1),
        "temperature": np.round(temperature, 2),
        "data_source": "synthetic",
    })

    return df


def generate_dataset(
    n_subjects: int = 10,
    samples_per_subject: int = 500,
    base_seed: int = 42,
    output_dir: Optional[str] = None,
) -> pd.DataFrame:
    """Generate a multi-subject synthetic dataset.

    Args:
        n_subjects: Number of subjects.
        samples_per_subject: Readings per subject.
        base_seed: Base random seed.
        output_dir: If provided, saves CSV and metadata.

    Returns:
        Combined DataFrame.
    """
    profiles = ["ascent", "descent", "plateau", "variable"]
    dfs = []

    for i in range(n_subjects):
        subject_id = f"SYNTH-{i+1:03d}"
        profile = profiles[i % len(profiles)]
        seed = base_seed + i

        df = generate_subject_data(
            subject_id=subject_id,
            n_samples=samples_per_subject,
            altitude_profile=profile,
            seed=seed,
        )
        dfs.append(df)

    combined = pd.concat(dfs, ignore_index=True)

    if output_dir:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        csv_path = out / "synthetic_altitude_physiology.csv"
        combined.to_csv(csv_path, index=False)

        # Compute file hash for reproducibility
        file_hash = hashlib.sha256(csv_path.read_bytes()).hexdigest()

        metadata = {
            "dataset_name": "HIMA-SHIELD Synthetic High-Altitude Physiological Data",
            "type": "SYNTHETIC — NOT REAL CLINICAL DATA",
            "description": (
                "Simulated physiological readings for demonstrating the "
                "HIMA-SHIELD analysis pipeline. Values are generated using "
                "published physiological ranges but do not represent real patients."
            ),
            "generation_date": datetime.now().isoformat(),
            "n_subjects": n_subjects,
            "samples_per_subject": samples_per_subject,
            "total_rows": len(combined),
            "base_seed": base_seed,
            "file_hash_sha256": file_hash,
            "columns": {
                "timestamp": "ISO 8601 datetime, 60s intervals",
                "subject_id": "Synthetic subject identifier (SYNTH-XXX)",
                "altitude": "Simulated altitude in meters (0-8848)",
                "heart_rate": "Simulated heart rate in bpm (40-200)",
                "spo2": "Simulated SpO2 percentage (50-100)",
                "respiratory_rate": "Simulated breaths per minute (6-50)",
                "temperature": "Simulated body temperature °C (34-42)",
                "data_source": "Always 'synthetic' for this dataset",
            },
            "physiological_basis": (
                "Ranges loosely based on published high-altitude physiology "
                "literature. Altitude effects are simplified linear models. "
                "No individual-level clinical validation."
            ),
            "licence": "Generated for research demonstration. No restrictions.",
        }

        with open(out / "dataset_metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)

    return combined


def inject_anomalies(
    df: pd.DataFrame,
    anomaly_fraction: float = 0.05,
    seed: int = 123,
) -> tuple[pd.DataFrame, pd.Series]:
    """Inject synthetic anomalies into the dataset.

    Returns the modified DataFrame and a boolean Series indicating injected anomalies.
    All injected anomalies are clearly marked.

    Args:
        df: Input DataFrame.
        anomaly_fraction: Fraction of rows to mark as anomalous.
        seed: Random seed.

    Returns:
        (modified_df, anomaly_labels)
    """
    rng = np.random.default_rng(seed)
    df = df.copy()
    n = len(df)
    n_anomalies = max(1, int(n * anomaly_fraction))

    anomaly_indices = rng.choice(n, size=n_anomalies, replace=False)
    labels = pd.Series(False, index=df.index)
    labels.iloc[anomaly_indices] = True

    # Inject physiologically extreme (but possible) values
    # Types: low_spo2 (hypoxaemia), high_hr (tachycardia), combined
    # (hypoxaemia + tachycardia), temp_spike (hyperthermia, 38.5-40.0 C).
    types = pd.Series("none", index=df.index, dtype=object)
    for idx in anomaly_indices:
        anomaly_type = rng.choice(["low_spo2", "high_hr", "combined", "temp_spike"])
        types.iloc[idx] = str(anomaly_type)
        if anomaly_type == "low_spo2":
            df.loc[df.index[idx], "spo2"] = rng.uniform(60, 75)
        elif anomaly_type == "high_hr":
            df.loc[df.index[idx], "heart_rate"] = rng.uniform(140, 180)
        elif anomaly_type == "combined":
            df.loc[df.index[idx], "spo2"] = rng.uniform(65, 78)
            df.loc[df.index[idx], "heart_rate"] = rng.uniform(130, 170)
        elif anomaly_type == "temp_spike":
            df.loc[df.index[idx], "temperature"] = rng.uniform(38.5, 40.0)

    df["injected_anomaly"] = labels
    df["anomaly_type"] = types
    df["data_source"] = df["data_source"].astype(str)  # ensure string type

    return df, labels


if __name__ == "__main__":
    import sys
    output = sys.argv[1] if len(sys.argv) > 1 else "./data/processed"
    dataset = generate_dataset(n_subjects=10, samples_per_subject=500, output_dir=output)
    print(f"Generated {len(dataset)} rows for {dataset['subject_id'].nunique()} subjects")
    print(f"Saved to {output}")
