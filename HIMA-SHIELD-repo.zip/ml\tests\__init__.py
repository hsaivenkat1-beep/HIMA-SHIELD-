# HIMA-SHIELD v4 test suite
